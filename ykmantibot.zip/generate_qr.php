<?php

/* setup includes */
require_once('includes/master.inc.php');

/* load url details */
if ($_REQUEST['url'])
{
    $shortUrl = end(explode('/', $_REQUEST['url']));
    $shortUrlObj = shortUrl::loadByUrl(str_replace(array("~q"), "", $shortUrl));
}
else
{
    /* if no short url found, redirect to home page */
    redirect(WEB_ROOT . "/index." . SITE_CONFIG_PAGE_EXTENSION);
}

// output qr code
$shortUrlPath = WEB_ROOT . '/' . str_replace(array("~q"), "", $shortUrl);
QRcode::png($shortUrlPath, false, QR_ECLEVEL_L, 3, 0);