<?php
/* setup includes */
require_once('includes/master.inc.php');

/* setup page */
define("PAGE_NAME", t("index_page_name"));
define("PAGE_DESCRIPTION", t("index_meta_description"));
define("PAGE_KEYWORDS", t("index_meta_keywords"));
define("SITE_SELECTED_PAGE", "home");
define("SITE_HEADER_TITLE", t('site_main_title', '<strong class="colored">[[[SITE_NAME]]]:</strong> paste your <span class="colored">long url</span> below to shorten.', array('SITE_NAME' => SITE_CONFIG_SITE_NAME)));

/* check for url request on redirect and remove if needbe */
if (isset($_REQUEST['url']))
{
    redirect(WEB_ROOT . "/");
}

/* show original url */
$showPreview = false;
if (isset($_REQUEST['p']))
{
    $showPreview = true;
}

// get base urls
$shortUrlDomains = getShortUrlDomains();

// get folder listing
if($Auth->loggedIn())
{
    $folderListing = $db->getRows("SELECT id, folder_name FROM shorturl_folder WHERE user_id = ".$Auth->id." ORDER BY folder_name");
}

/* validate any submission */
require_once('_indexAction.inc.php');

/* header section */
require_once('_header.php');

/* index JS */
require_once('_indexJS.inc.php');

// load stats for later
$totalUrls    = $db->getValue('SELECT COUNT(id) AS total FROM shorturl');
$totalVisits  = $db->getValue('SELECT SUM(visits) AS total FROM shorturl');
$totalNewUrls = $db->getValue('SELECT COUNT(id) AS total FROM shorturl WHERE dateCreated > DATE_SUB(CURDATE(), INTERVAL 1 WEEK)');
?>

<div class="span12">
    <div class="row">
        <div class="span8 page_sidebar">

            <?php
            if ((isset($_REQUEST['success'])) && ((int) $_REQUEST['success'] == 1))
            {
                $urlIds = explode("|", $_REQUEST['u']);
                if (COUNT($urlIds))
                {
                    foreach ($urlIds AS $urlId)
                    {
                        $shortUrlObj = shortUrl::loadById((int) $urlId);
                        $shortUrl    = $shortUrlObj->compileShortUrl();

                        /* output result */
                        ?>

                        <div class="well shortUrlResultWrapper"> 
                            <!-- short url result -->
                            <div class="shortUrlResult">
                                <div class="shortUrlResultTick">
                                    <img src="<?php echo SITE_IMAGE_PATH; ?>/success_tick.png" width="43" height="32" alt="success"/>
                                </div>
                                <div class="resultLink">
                                    <a href="<?php echo $shortUrl; ?>" target="_blank"><?php echo safeOutputToScreen($shortUrl); ?></a>&nbsp;&nbsp;
                                    <i class="fa fa-clipboard" style="cursor: pointer;position:relative;top: -4px;" id="copyClipboard<?php echo $urlId; ?>" data-clipboard-text="<?php echo $shortUrl; ?>" title="<?php echo t('copy_to_clipboard', 'Copy to clipboard'); ?>" onmousedown="this.style.color='#FF0000'" onmouseup="this.style.color='#000000'"></i>
                                </div>
                                <div class="clear"><!-- --></div>
                            </div>
                            <script type="text/javascript">
                             var clip = new ZeroClipboard( document.getElementById('copyClipboard<?php echo $urlId; ?>') ); 
                            </script> 
                            <div class="clear"><!-- --></div>

                            <div class="shortUrlResult">
                                <div class="qrcode">
                                    <img src="<?php echo safeOutputToScreen($shortUrl); ?>~q" alt="<?php echo t('qr_code', 'QR Code'); ?>"/>
                                </div>

                                <div class="tableWrapper">
                                    <?php if ((SITE_CONFIG_ENABLE_STATS == "yes") || ($showPreview)): ?>
                                        <table class="table table-bordered table-striped">
                                            <tbody>
                                                <?php if (SITE_CONFIG_ENABLE_STATS == "yes"): ?>
                                                    <tr>
                                                        <td style="width: 110px;">
                                                            <?php echo t("url_statistics", "Url Statistics"); ?>:
                                                        </td>
                                                        <td>
                                                            <a href='<?php echo safeOutputToScreen($shortUrl); ?>~s' target='_blank'><?php echo safeOutputToScreen($shortUrlObj->shortUrlPart); ?>~s</a>
                                                            <i class="fa fa-clipboard" style="padding-left:5px;cursor:pointer;position:relative;top: -4px;" id="copyStats<?php echo $urlId; ?>~s" data-clipboard-text="<?php echo $shortUrl; ?>~s" title="<?php echo t('copy_to_clipboard', 'Copy to clipboard'); ?>" onmousedown="this.style.color='#FF0000'" onmouseup="this.style.color='#000000'"></i>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                                <?php if ($showPreview): ?>
                                                    <tr>
                                                        <td style="width: 110px;">
                                                            <?php echo t("original_url", "Original Url"); ?>:
                                                        </td>
                                                        <td>
                                                            <font style="color: #777;"><?php echo safeOutputToScreen($shortUrlObj->fullUrl); ?></font>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                                <tr>
                                                    <td style="width: 110px;">
                                                        <?php echo t("qr_code", "QR Code Link"); ?>:
                                                    </td>
                                                    <td>
                                                        <a href='<?php echo safeOutputToScreen($shortUrl); ?>~q' target='_blank'><?php echo safeOutputToScreen($shortUrlObj->shortUrlPart); ?>~q</a>
                                                        <i class="fa fa-clipboard" style="padding-left:5px;cursor:pointer;position:relative;top: -4px;" id="copyQR<?php echo $urlId; ?>~q" data-clipboard-text="<?php echo $shortUrl; ?>~q" title="<?php echo t('copy_to_clipboard', 'Copy to clipboard'); ?>" onmousedown="this.style.color='#FF0000'" onmouseup="this.style.color='#000000'"></i>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <script type="text/javascript">
                                         var clip = new ZeroClipboard( document.getElementById('copyStats<?php echo $urlId; ?>~s') ); 
                                         var clip = new ZeroClipboard( document.getElementById('copyQR<?php echo $urlId; ?>~q') ); 
                                        </script> 
                                    <?php endif; ?>
                                </div>

                                <div class="shareButtons">
                                    <!-- AddThis Button BEGIN -->
                                    <div class="addthis_toolbox addthis_default_style addthis_32x32_style">
                                        <a class="addthis_button_preferred_1" addthis:url="<?php echo safeOutputToScreen($shortUrl); ?>"></a>
                                        <a class="addthis_button_preferred_2" addthis:url="<?php echo safeOutputToScreen($shortUrl); ?>"></a>
                                        <a class="addthis_button_preferred_3" addthis:url="<?php echo safeOutputToScreen($shortUrl); ?>"></a>
                                        <a class="addthis_button_preferred_4" addthis:url="<?php echo safeOutputToScreen($shortUrl); ?>"></a>
                                        <a class="addthis_button_preferred_5" addthis:url="<?php echo safeOutputToScreen($shortUrl); ?>"></a>
                                        <a class="addthis_button_preferred_6" addthis:url="<?php echo safeOutputToScreen($shortUrl); ?>"></a>
                                        <a class="addthis_button_preferred_7" addthis:url="<?php echo safeOutputToScreen($shortUrl); ?>"></a>
                                        <a class="addthis_button_compact" addthis:url="<?php echo safeOutputToScreen($shortUrl); ?>"></a>
                                        <a class="addthis_counter addthis_bubble_style" addthis:url="<?php echo safeOutputToScreen($shortUrl); ?>"></a>
                                    </div>
                                    <!-- AddThis Button END -->
                                </div>
                                <div class="clear"><!-- --></div>
                            </div>
                            <div class="clear"><!-- --></div>
                        </div>
                        <div class="clear"><!-- --></div>

                        <?php
                    }
                    ?>
                    <script type="text/javascript" src="https://s7.addthis.com/js/250/addthis_widget.js#pubid=xa-4f44f44768bcd979"></script>
                    <?php
                }
            }
            ?>

            <div class="createUrlWrapper">
                <?php
                if (isErrors())
                {
                    echo outputErrors();
                }
                ?>

                <!-- main search box -->
                <form method="POST" action="index.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>" autocomplete="off" class="form">
                    <div class="well">  
                        <h5 style="font-weight: 600; text-transform: uppercase !important;">
                            <?php echo t('enter_your_long_urls_below', 'Enter one or more long urls below'); ?>
                        </h5>
                        <hr/>

                        <div>
                            <textarea name="longUrl" id="longUrl" placeholder="https://..." title="<?php echo t("enter_your_long_url"); ?>" style="outline: none;"><?php echo safeOutputToScreen(isset($longUrl)?$longUrl:''); ?></textarea>
                        </div>
                        <div class="clear"><!-- --></div>


                        <div>
                            <label for="shortUrlDomain"><?php echo t("short_url_domain", "Short Url Domain"); ?>:</label>
                            <select id="shortUrlDomain" name="shortUrlDomain" style="width: 100%;">
                                <?php
                                foreach ($shortUrlDomains AS $k => $shortUrlDomain)
                                {
                                    // active domains only
                                    if($shortUrlDomain['status'] != 'enabled')
                                    {
                                        continue;
                                    }
                                    
                                    // disabled item
                                    $disabled = false;
                                    if(($shortUrlDomain['premium_only'] == 1) && ($Auth->level == 'guest'))
                                    {
                                        $disabled = true;
                                    }
                                    elseif(($shortUrlDomain['premium_only'] == 2) && (in_array($Auth->level, array('guest', 'free user', 'user'))))
                                    {
                                        $disabled = true;
                                    }
                                    
                                    // check for account only
                                    if(($shortUrlDomain['premium_only'] == 1) && ($lastPremiumOnly != $shortUrlDomain['premium_only']))
                                    {
                                        echo '<optgroup label="'.safeOutputToScreen(t("registered_users_only", "Registered Users Only")).'">';
                                    }
                                    
                                    if(($shortUrlDomain['premium_only'] == 2) && ($lastPremiumOnly != $shortUrlDomain['premium_only']))
                                    {
                                        echo '</optgroup>';
                                        echo '<optgroup label="'.safeOutputToScreen(t("paid_users_only", "Paid Users Only")).'">';
                                    }
                                    
                                    $lastPremiumOnly = $shortUrlDomain['premium_only'];

                                    echo '<option value="' . (int) $k . '"';
                                    
                                    // selected option
                                    if(isset($_REQUEST['shortUrlDomain']))
                                    {
                                        if ($k == (int) $_REQUEST['shortUrlDomain'])
                                        {
                                            echo ' SELECTED';
                                        }
                                    }
                                    
                                    // disabled option
                                    if($disabled == true)
                                    {
                                        echo ' disabled="disabled"';
                                    }

                                    echo '>';

                                    echo $shortUrlDomain['domain'];
                                    if($disabled == true)
                                    {
                                        echo ' ('.safeOutputToScreen(t('unavailable', 'unavailable')).')';
                                    }
                                    
                                    '</option>';
                                }
                                echo '</optgroup>';
                                ?>
                            </select>
                        </div>


                        <?php if (SITE_CONFIG_CREATE_URL_SHOW_TERMS_CHECKBOX == 'Show'): ?>
                            <div class="termsWrapper">
                                <input name="agreeTerms" id="agreeTerms" type="checkbox" value="1"/>
                                <label for="agreeTerms">
                                    <?php echo t('agree_with_our_terms', 'Agree with our <a href="terms.[[[SITE_CONFIG_PAGE_EXTENSION]]]" target="_blank">terms</a>.', array('SITE_CONFIG_PAGE_EXTENSION' => SITE_CONFIG_PAGE_EXTENSION)); ?>
                                </label>
                            </div>
                        <?php endif; ?>

                        <div class="createButtonWrapper">
                            <input name="submitted" type="hidden" value="1"/>
                            <button type="submit" class="btn btn-large btn-primary"><?php echo t('create_url', 'Create Url'); ?></button>
                        </div>

                        <div class="clear"><!-- --></div>
                    </div>

                    <!-- additional options -->
                    <div class="well">
                        <h5 style="font-weight: 600; text-transform: uppercase !important;">
                            <?php echo t("additional_options", "additional options"); ?>
                        </h5>
                        <hr/>
                        <div class="additionalOptions">
                            <?php
                            $className = 'fiftyPercent';
                            if(($Auth->loggedIn()))
                            {
                                $className = 'third';
                            }
                            ?>
                            
                            <?php
                            if ($Auth->loggedIn())
                            {
                                ?>
                                <div class="third">
                                    <label for="shortUrlFolder"><?php echo t("index_save_to_folder", "Save To Folder"); ?>:</label>
                                    <select id="shortUrlFolder" name="shortUrlFolder">
                                        <option value="">- <?php echo t('none', 'none'); ?>-</option>
                                        <?php
                                        foreach ($folderListing AS $folderItem)
                                        {
                                            echo '<option value="' . $folderItem['id'] . '"';
                                            if ($folderItem['id'] == (int)$_REQUEST['shortUrlFolder'])
                                            {
                                                echo ' SELECTED';
                                            }
                                            echo '>' . $folderItem['folder_name'] . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <?php
                            }
                            ?>

                            <div class="<?php echo $className; ?>">
                                <label for="customUrl">
                                    <?php echo t("custom_url"); ?>:
                                </label>
                                <input type="text" name="customUrl" id="customUrl" title="<?php echo t("set_a_custom_url"); ?>" value="<?php echo safeOutputToScreen(isset($_REQUEST['customUrl'])?$_REQUEST['customUrl']:''); ?>" autocomplete="off"/>
                            </div>

                            <div class="<?php echo $className; ?>Last">
                                <label for="shortUrlPassword"><?php echo t("index_password"); ?>:</label>
                                <input type="text" name="shortUrlPassword" id="shortUrlPassword" title="<?php echo t("set_the_password_to_access_link"); ?>" value="<?php echo safeOutputToScreen(isset($_REQUEST['shortUrlPassword'])?$_REQUEST['shortUrlPassword']:''); ?>" autocomplete="off"/>
                            </div>

                            <div class="third">
                                <label for="shortUrlExpiryDate"><?php echo t("expiry_date"); ?>:</label>
                                <input type="text" class="uiStyle" name="shortUrlExpiryDate" id="shortUrlExpiryDate" title="<?php echo t("set_an_expiry_date_for_url"); ?>" value="<?php echo safeOutputToScreen(isset($_REQUEST['shortUrlExpiryDate'])?$_REQUEST['shortUrlExpiryDate']:''); ?>"/>
                            </div>

                            <div class="third">
                                <label for="shortUrlUses"><?php echo t("url_total_uses"); ?>:</label>
                                <select id="shortUrlUses" name="shortUrlUses" title="<?php echo t("total_uses_before_url_expires"); ?>">
                                    <?php
                                    $options = array(0    => t("unlimited"), 1    => "1", 2    => "2", 3    => "3", 5    => "5", 10   => "10", 20   => "20", 50   => "50", 100  => "100", 500  => "500", 1000 => "1000");
                                    foreach ($options AS $k => $option)
                                    {
                                        echo '<option value="' . (string) $k . '"';
                                        if(isset($_REQUEST['shortUrlUses']))
                                        {
                                            if ($k == (int) $_REQUEST['shortUrlUses'])
                                            {
                                                echo ' SELECTED';
                                            }
                                        }
                                        echo '>' . $option . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="thirdLast">
                                <label for="shortUrlType"><?php echo t("url_type", "Url Type"); ?>:</label>
                                <select id="shortUrlType" name="shortUrlType">
                                    <?php
                                    $shortUrlType = 0;
                                    if ($Auth->loggedIn())
                                    {
                                        $shortUrlType = 1;
                                    }
                                    if (isset($_REQUEST['shortUrlType']))
                                    {
                                        $shortUrlType = $_REQUEST['shortUrlType'];
                                    }
                                    $options = array(0 => t("public_listing_on_site", "public (listed on site)"), 1 => t("private_not_listed_on_site", "private (not listed on site)"));
                                    foreach ($options AS $k => $option)
                                    {
                                        echo '<option value="' . (string) $k . '"';
                                        if ($k == (int) $shortUrlType)
                                        {
                                            echo ' SELECTED';
                                        }
                                        echo '>' . $option . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="clear"><!-- --></div>
                            
                            <?php
                            // do any plugin includes
                            pluginHelper::includeAppends('index_additional_option_fields.php', array('Auth'             => $Auth));
                            ?>

                        </div>
                    </div>
                </form>

                <!-- JS bookmarks -->
                <div class="bookmarkItems">
                    <div class="subBoomarkItem">
                        <a onClick="bookmarksite('<?php echo str_replace("'", "", SITE_CONFIG_SITE_NAME); ?>', '<?php echo WEB_ROOT; ?>');
                                return false;" class="btn mrgbtm35"><span style=""><?php echo t("add_to_bookmarks", "Add To Bookmarks"); ?></span>
                            <img alt="<?php echo t("add_to_bookmarks", "Add To Bookmarks"); ?>" src="<?php echo SITE_IMAGE_PATH; ?>/star_icon.png"/>
                        </a>
                    </div>
                    <div class="subBoomarkItem">
                        <a href="javascript:void(location.href='<?php echo WEB_ROOT; ?>/index.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>?agreeTerms=1&submitted=1&longUrl='+encodeURIComponent(location.href.replace('http://','')));" onClick="alert(t('toolbar_quicklink_alert'));
                                return false;" class="btn mrgbtm35"><span style=""><?php echo t("create_short_url", "Create Short Url"); ?></span>
                            <img alt="<?php echo t("create_short_url", "Create Short Url"); ?>" src="<?php echo SITE_IMAGE_PATH; ?>/plus_icon.png"/>
                        </a>
                    </div>
                    <div class="subBoomarkItem">
                        <a href="javascript:void(location.href='<?php echo WEB_ROOT; ?>/index.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>?agreeTerms=1&submitted=1&postToTwitter=1&longUrl='+encodeURIComponent(location.href.replace('http://','')));" onClick="alert(t('twitter_quicklink_alert'));
                                return false;" class="btn mrgbtm35"><span style=""><?php echo t("post_on_twitter", "Quick Post To Twitter"); ?></span>
                            <img alt="<?php echo t("post_on_twitter", "Quick Post To Twitter"); ?>" src="<?php echo SITE_IMAGE_PATH; ?>/twitter_icon.png"/>
                        </a>
                    </div>
                    <div class="clear"><!-- --></div>
                </div>

            </div>

        </div>

        <div class="span4 hidden-phone column_container indexRight">
            <div class="row-fluid">
                <div class="span12">

                    <div style="background-color: rgb(58, 58, 58); padding: 10px; margin-bottom: 20px;">
                        <h1 style="color: rgb(255, 255, 255) !important; margin-bottom: 3px !important;"><b><?php echo t('header_shorten_urls', 'SHORTEN URLS!'); ?></b></h1>
                        <h5 style="color: rgb(255, 255, 255);"><?php echo t('eaily_create_trackable_short_urls_to_use_anywhere', 'Easily create trackable short urls to use anywhere on the web, email or Twitter.'); ?></h5>
                    </div>

                    <p>
                        <?php echo t('homepage_intro_text', 'Copy and paste your long url into the box on the left or signup for a <a href="[[[WEB_ROOT]]]/register.[[[SITE_CONFIG_PAGE_EXTENSION]]]">free account</a> and manage all your short urls in one place.', array('SITE_CONFIG_PAGE_EXTENSION' => SITE_CONFIG_PAGE_EXTENSION, 'WEB_ROOT'                   => WEB_ROOT)); ?>
                    </p>

                    <p>
<?php echo t('we_use_the_most_up_to_date_sources_malware_phishing', 'We use the most up to date sources available on the internet to block links being created for sites which may contain viruses, spam or malware.'); ?>
                    </p>
                    <ul>
                        <li><a href="https://www.phishtank.com/" target="_blank"><?php echo t('phishtank', 'PhishTank'); ?></a></li>
                        <li><a href="https://developers.google.com/safe-browsing/" target="_blank"><?php echo t('google_safe_browsing', 'Google Safe Browsing'); ?></a></li>
                    </ul>


                    <hr class="visible-desktop"></hr>
                    <h4 class="visible-desktop"><?php echo t('site_statistics', 'Site Statistics'); ?>:</h4>

                    <div class="span6 statBox statBoxFirst" style="margin-left: 0px;">
                        <div class="interalWrapper">
                            <p>
<?php echo number_format($totalUrls, 0); ?>
                            </p>
                            <h4><?php echo t('total_short_urls', 'Total Short Urls'); ?></h4>
                        </div>
                    </div>
                    <div class="span6 statBox" style="margin-left: 0px;">
                        <div class="interalWrapper">
                            <p>
<?php echo number_format($totalVisits, 0); ?>
                            </p>
                            <h4><?php echo t('total_url_visits', 'Total Url Visits'); ?></h4>
                        </div>
                    </div>
                    <div class="clear"><!-- --></div>

                </div>
            </div>
        </div>

    </div>

    <!-- divider -->
    <div class="row">
        <div class="span12">
            <div class="home_separator"></div>
        </div>
    </div> 

</div>

<?php
require_once('_footer.php');
?>