<?php

/* setup includes */
require_once('includes/master.inc.php');

/* require login */
$Auth->requireUser('login.php');

// allow for 10 minutes for the export
set_time_limit(60 * 10);

/* resulting csv data */
$formattedCSVData = array();

/* header */
$lArr = array();
$lArr[]             = "Short Url";
$lArr[]             = "Original Url";
$lArr[]             = "Created Date";
$lArr[]             = "Visits";
$lArr[]             = "Expires";
$lArr[]             = "Available Uses";
$lArr[]             = "Last Accessed";
$lArr[]             = "Status";
$lArr[]             = "Folder Name";
$formattedCSVData[] = "\"" . implode("\",\"", $lArr) . "\"";

$urlData = $db->getRows("SELECT shorturl.*, shorturl_folder.folder_name AS folderName FROM shorturl LEFT OUTER JOIN shorturl_folder ON shorturl.shortUrlFolder = shorturl_folder.id WHERE shorturl.userId = ".$Auth->id." ORDER BY shorturl.id");

foreach ($urlData AS $row)
{   
    $lArr   = array();
    $lArr[] = WEB_ROOT . "/" . $row['shortUrl'];
    $lArr[] = $row['originalUrl'];
    $lArr[] = dater($row['dateCreated']);
    $lArr[] = $row['visits'];
    $lArr[] = ($row['expiryDate'] != "0000-00-00 00:00:00") ? dater($row['expiryDate']) : "0";
    $lArr[] = $row['totalUses'];
    $lArr[] = ($row['lastAccessed'] != "0000-00-00 00:00:00") ? dater($row['lastAccessed']) : "0";
    $lArr[] = $row['status'];
    $lArr[] = ($row['folderName'] ? $row['folderName'] : '');

    $formattedCSVData[] = "\"" . implode("\",\"", $lArr) . "\"";
}

$outname = "url_data.csv";
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Content-type: text/plain;");
header("Content-Transfer-Encoding: binary;");
header("Content-Disposition: attachment; filename=\"$outname\";");

echo implode("\n", $formattedCSVData);
exit;