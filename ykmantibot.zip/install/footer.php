<table cellspacing="0" cellpadding="0" width="1000px" border="0">
    <tbody>
        <tr><td height="20px"></td></tr>
        <tr>
            <td class="footer">
                MFScripts Installer&nbsp;&nbsp;|&nbsp;&nbsp;<a href='http://www.mfscripts.com'>MFScripts</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://forum.mfscripts.com" target="_blank">Support</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.mfscripts.com/terms.html" target="_blank"><?php echo lang_key("license"); ?></a>  
            </td>
        </tr>
        <tr><td height="7px"></td></tr>
    </tbody>
</table>

