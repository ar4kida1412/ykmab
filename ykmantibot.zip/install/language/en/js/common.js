EasyInstaller = function () {

};

EasyInstaller._MSG = {};
EasyInstaller._MSG["ajax_connection_error"] = "AJAX: cannot connect to the server or server response error! Please try again later.";
EasyInstaller._MSG["db_version"] = "DB Version";
EasyInstaller._MSG["error"] = "Error!";
EasyInstaller._MSG["success"] = "Success!";
EasyInstaller._MSG["connection_was_established"] = "A connection was successfully established with the server.";
EasyInstaller._MSG["connection_error"] = "Wrong parameters passed or connection error!";

