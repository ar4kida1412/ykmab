<?php
// load hybridauth
$config = PLUGIN_DIRECTORY_ROOT . 'sociallogin/includes/hybridauth/config.php';
require_once(PLUGIN_DIRECTORY_ROOT . 'sociallogin/includes/hybridauth/Hybrid/Auth.php');

// load plugin details
$pluginDetails  = pluginHelper::pluginSpecificConfiguration('sociallogin');
$pluginConfig   = $pluginDetails['config'];
$pluginSettings = json_decode($pluginDetails['data']['plugin_settings'], true);

// only if user is logged in
$Auth = Auth::getAuth();
if ($Auth->loggedIn() == true)
{
    if(isset($_SESSION['socialLogin']))
    {
        $homeLink = '';
        
        // override logout link
        $user_data = (array)unserialize($_SESSION['socialData']);
		$homeLink = '<li'.(SITE_SELECTED_PAGE == "account_home" ? ' class="current-menu-item"' : '').'><a href="'.WEB_ROOT.'/account_home.'.SITE_CONFIG_PAGE_EXTENSION.'">'.strtoupper(t('your_urls', 'your urls'));
        if(strlen($user_data['photoURL']))
        {
            $imageText = t('plugin_sociallogin_logged_in_as', 'Logged in as').' \''.$user_data['displayName'].'\' '.t('plugin_sociallogin_via', 'via').' '.UCWords($_SESSION['socialProvider']);
            $homeLink .= '&nbsp;&nbsp;<span class="pluginSocialLoginProfileThumb"><img src="'.$user_data['photoURL'].'" style="float: left;width: 22px; height: 22px; position: fixed; margin-left: 4px; border: 1px solid #fff; margin-top:-2px;" title="'.  safeOutputToScreen($imageText).'"/></span><span style="width: 26px;float: left;"></span>';
        }
        elseif(strlen($user_data['displayName']))
        {
            $homeLink .= '&nbsp;('.safeOutputToScreen($user_data['displayName'], null, 20).')';
        }
		$homeLink .= '</a></li>';
        $params['account_home'] = $homeLink;
    }
}
?>