<?php

// core plugin config
$pluginConfig = array();
$pluginConfig['plugin_name']             = 'Social Login';
$pluginConfig['folder_name']             = 'sociallogin';
$pluginConfig['plugin_description']      = 'Login with your Facebook, Twitter or Google Account.';
$pluginConfig['plugin_version']          = 3;
$pluginConfig['required_script_version'] = 3.4;
