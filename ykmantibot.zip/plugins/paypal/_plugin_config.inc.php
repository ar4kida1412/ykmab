<?php

// core plugin config
$pluginConfig = array();
$pluginConfig['plugin_name']             = 'PayPal Payment Integration';
$pluginConfig['folder_name']             = 'paypal';
$pluginConfig['plugin_description']      = 'Accept payments using PayPal.';
$pluginConfig['plugin_version']          = 1;
$pluginConfig['required_script_version'] = 3.4;
