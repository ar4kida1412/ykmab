<?php

require_once('includes/master.inc.php');

/* try to load in shorturl and redirect as required */
if((int) $_REQUEST['u'])
{
    if(!$shortUrlObj = shortUrl::loadById((int) $_REQUEST['u']))
    {
        redirect(WEB_ROOT . "/error." . SITE_CONFIG_PAGE_EXTENSION);
    }
}
elseif($_REQUEST['url'])
{
    $url = trim($_REQUEST['url']);

    // remove any forward slash from the end
    if(substr($url, strlen($url) - 1, 1) == '/')
    {
        $url = substr($url, 0, strlen($url) - 1);
    }
    $url = end(explode('/', $url));
    
    $shortUrlObj = shortUrl::loadByUrl($url);
}
else
{
    /* if no short url found, redirect to home page */
    redirect(WEB_ROOT . "/index." . SITE_CONFIG_PAGE_EXTENSION);
}

/* is the url still active */
if($shortUrlObj->status != "active")
{
    $errorMsg = t("error_short_url_no_longer_active");
    redirect(WEB_ROOT . "/error." . SITE_CONFIG_PAGE_EXTENSION . "?e=" . urlencode($errorMsg));
}

/* has the url exceeded it's max uses */
if((int) $shortUrlObj->totalUses > 0)
{
    if((int) $shortUrlObj->visits >= (int) $shortUrlObj->totalUses)
    {
        /* set status to expired */
        $db->query('UPDATE shorturl SET status = :status WHERE id = :id', array('status' => 'expired', 'id' => $shortUrlObj->id));

        $errorMsg = t("short_url_reached_usage_limit");
        redirect(WEB_ROOT . "/error." . SITE_CONFIG_PAGE_EXTENSION . "?e=" . urlencode($errorMsg));
    }
}

/* is it past it's expiry date? */
if(strlen($shortUrlObj->expiryDate))
{
    if(($shortUrlObj->expiryDate < date("Y-m-d H:i:s")) && ($shortUrlObj->expiryDate != "0000-00-00 00:00:00"))
    {
        /* set status to expired */
        $db->query('UPDATE shorturl SET status = :status WHERE id = :id', array('status' => 'expired', 'id' => $shortUrlObj->id));

        $errorMsg = t("short_url_expired");
        redirect(WEB_ROOT . "/error." . SITE_CONFIG_PAGE_EXTENSION . "?e=" . urlencode($errorMsg));
    }
}

/* do we have the password and is it correct? */
if(strlen($shortUrlObj->password))
{
    if(!$_REQUEST['accessPass'])
    {
        redirect(WEB_ROOT . "/accessRestricted." . SITE_CONFIG_PAGE_EXTENSION . "?u=" . (int) $shortUrlObj->id);
    }
    elseif($shortUrlObj->password != MD5($_REQUEST['accessPass']))
    {
        $errorMsg = t("password_incorrect");
        redirect(WEB_ROOT . "/accessRestricted." . SITE_CONFIG_PAGE_EXTENSION . "?u=" . (int) $shortUrlObj->id . "&e=" . urlencode($errorMsg));
    }
}

/* update stats */
$rs = Stats::track($shortUrlObj, $shortUrlObj->id);
if($rs)
{
    $shortUrlObj->updateLastAccessed();
}

/* redirect type */
$redirectType = SITE_CONFIG_REDIRECT_TYPE;

// do any plugin includes
$params = pluginHelper::includeAppends('url_redirector_complete.php', array('redirectType' => $redirectType, 'Auth' => $Auth, 'shortUrlObj' => $shortUrlObj));
$redirectType = $params['redirectType'];

/* check for redirect override */
if(defined("SITE_CONFIG_REDIRECT_OVERRIDE"))
{
    if(strlen(SITE_CONFIG_REDIRECT_OVERRIDE))
    {
        /* prepare full url host */
        $urlParts = parse_url($shortUrlObj->fullUrl);
        $urlHost = str_replace("www.", "", strtolower(trim($urlParts['host'])));

        $sites = explode("|", SITE_CONFIG_REDIRECT_OVERRIDE);
        foreach($sites AS $site)
        {
            /* prepare site */
            $site = strtolower(trim($site));
            $site = str_replace("www.", "", $site);
            $site = str_replace("http://", "", $site);

            /* compare site url with redirect override url */
            if($urlHost == $site)
            {
                $redirectType = 'Direct';
            }
        }
    }
}

// override paid accounts
if(isPaidUser() == true)
{
    $redirectType = 'Direct';
}

/* how should we redirect them */
switch($redirectType)
{
    case "Top Bar":
        $u = $shortUrlObj->id;
        $_REQUEST['p'] = "top";
        include_once("framedRedirect.php");
        break;
    case "Bottom Bar":
        $u = $shortUrlObj->id;
        $_REQUEST['p'] = "top";
        include_once("framedRedirectB.php");
        break;
    case "Interstitial Ads":
        $u = $shortUrlObj->id;
        include_once("interstitualAd.php");
        break;
    case "Meta Delay Redirect":
        $u = $shortUrlObj->id;
        include_once("delayedRedirect.php");
        break;
    case "Custom Redirect":
        $u = $shortUrlObj->id;
        include_once("delayedRedirectB.php");
        break;
    /* Direct */
    default:
        header('HTTP/1.1 301 Moved Permanently');
        redirect($shortUrlObj->fullUrl);
        break;
}
