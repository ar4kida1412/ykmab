<?php

// output 404 header
header("HTTP/1.0 404 Not Found");

/* setup includes */
require_once('includes/master.inc.php');

/* setup page */
define("PAGE_NAME", t("404_page_name", "404 Error"));
define("PAGE_DESCRIPTION", t("404_meta_description", "404 Error"));
define("PAGE_KEYWORDS", t("404_meta_keywords", "404, api, application, programming, interface, short, url, site"));
define("SITE_SELECTED_PAGE", "");

require_once('_header.php');
?>

<div class="span12 center">
	<h3>
	<strong class="colored" style="font-size: 107px; line-height: 130px;"><?php echo t('404_oops_404', 'Oops, 404!'); ?></strong>
	<br/>
	<?php echo t('404_the_page_you_were_looking_for_could_not_be_found', 'The page you were looking for could not be found.'); ?>
	</h3>
	<br/>
</div>

<?php
require_once('_footer.php');
?>