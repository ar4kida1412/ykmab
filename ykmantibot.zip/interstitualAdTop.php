<?php
/* setup includes */
require_once('includes/master.inc.php');

$url          = (int) $_REQUEST['url'];
$shortUrlObj  = shortUrl::loadByID($url);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="copyright" content="Copyright &copy; <?php echo date("Y"); ?> - <?php echo SITE_CONFIG_SITE_NAME; ?>"/>
        <meta name="robots" content="all"/>
        <meta http-equiv="Cache-Control" content="no-cache" />
        <meta http-equiv="Expires" content="-1" />
        <meta http-equiv="Pragma" content="no-cache" />
        <link href="<?php echo SITE_CSS_PATH; ?>/css/bootstrap.css" rel="stylesheet"/>
        <link rel="stylesheet" href="<?php echo SITE_CSS_PATH; ?>/screen.css" type="text/css" media="screen" title="Screen" charset="utf-8" />
        <script src="<?php echo SITE_JS_PATH; ?>/jquery.min.js"></script>
        <script>
        $=jQuery;
        var milisec = 0;
        var seconds = <?php echo (int) SITE_CONFIG_INTERSTITIAL_AD_COUNTDOWN>0?SITE_CONFIG_INTERSTITIAL_AD_COUNTDOWN:5; ?>;

        function display()
        { 
            if (milisec<=0)
            {
                milisec	= 9;
                seconds	-= 1;
            }
            if (seconds<=-1)
            {
                milisec = 0;
                seconds += 1;
            } 
            else
            {
                milisec -= 1;
            }
            
            if(seconds == 0)
            {
                $("#countDownTimer").hide();
                $("#continueButton").show();
            }
            else
            {
                $("#countDownTimer").html("Please wait <span class='interSecondsText'>"+seconds+"</span> second...");
                if(seconds != 1)
                {
                    $("#countDownTimer").html("Please wait <span class='interSecondsText'>"+seconds+"</span> seconds...");
                }
                setTimeout("display()", 100);
            }
        }

        $(document).ready(function($) {
            $("#countDownTimer").html('30');
            display();
        });
    </script>
    </head>
    <body>
        <div class="framedRedirectTopFrameWrapper" style="height: <?php echo SITE_CONFIG_TOP_IFRAME_HEIGHT; ?>px;">
            <div class="rightAdContent">
                <div id="countDownTimer" class="interCountDownTimer">
                    
                </div>
                <div id="continueButton" class="interContinueButton" style="display: none;">
                    <a href="<?php echo safeOutputToScreen($shortUrlObj->fullUrl); ?>" class="btn btn-large btn-primary" target="_parent"><?php echo t('skip_advert', 'skip advert'); ?> </a>
                </div>
            </div>
            <div class="leftContent" style="height: <?php echo SITE_CONFIG_TOP_IFRAME_HEIGHT; ?>px;" onClick="parent.location = '<?php echo WEB_ROOT; ?>';">
                <?php
                $logoFilename = '_default';
                if (SITE_CONFIG_SITE_THEME == 'v3')
                {
                    $logoFilename = SITE_CONFIG_SITE_THEME_STYLE;
                }
                ?>
                <img src="<?php echo SITE_IMAGE_PATH; ?>/logo/<?php echo $logoFilename; ?>.png" alt="<?php echo SITE_CONFIG_SITE_NAME; ?>"/>
            </div>
            <div class="clear"></div>
            <div class="footerBar"></div>
        </div>
    </body>
</html>

