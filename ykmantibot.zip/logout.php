<?php

/* setup includes */
require_once('includes/master.inc.php');

$Auth->logout();
redirect(WEB_ROOT);