<?php
/* setup includes */
require_once('includes/master.inc.php');

$url          = (int) $_REQUEST['url'];
$shortUrlObj  = shortUrl::loadByID($url);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="copyright" content="Copyright &copy; <?php echo date("Y"); ?> - <?php echo SITE_CONFIG_SITE_NAME; ?>"/>
        <meta name="robots" content="all"/>
        <meta http-equiv="Cache-Control" content="no-cache" />
        <meta http-equiv="Expires" content="-1" />
        <meta http-equiv="Pragma" content="no-cache" />
        <link href="<?php echo SITE_CSS_PATH; ?>/css/bootstrap.css" rel="stylesheet"/>
        <link rel="stylesheet" href="<?php echo SITE_CSS_PATH; ?>/screen.css" type="text/css" media="screen" title="Screen" charset="utf-8" />
    </head>
    <body>
        <div class="framedRedirectTopFrameWrapper" style="height: <?php echo SITE_CONFIG_TOP_IFRAME_HEIGHT; ?>px;">
            <div class="rightAdContent">
                <!-- ads -->
                <div>
                    <?php echo SITE_CONFIG_ADVERT_IFRAME_REDIRECT; ?>
                </div>
            </div>
            <div class="rightContent">
                <a href="<?php echo WEB_ROOT; ?>" target="_parent"><?php echo t("create_short_url"); ?></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="<?php echo WEB_ROOT; ?>/report_url.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>?url=<?php echo $url; ?>&problemUrl=<?php echo urlencode($shortUrlObj->compileShortUrl()); ?>" target="_parent"><?php echo t("report_abuse"); ?></a>
            </div>
            <div class="leftContent" style="height: <?php echo SITE_CONFIG_TOP_IFRAME_HEIGHT; ?>px;" onClick="parent.location = '<?php echo WEB_ROOT; ?>';">
                <?php
                $logoFilename = '_default';
                if (SITE_CONFIG_SITE_THEME == 'v3')
                {
                    $logoFilename = SITE_CONFIG_SITE_THEME_STYLE;
                }
                ?>
                <img src="<?php echo SITE_IMAGE_PATH; ?>/logo/<?php echo $logoFilename; ?>.png" alt="<?php echo SITE_CONFIG_SITE_NAME; ?>"/>
            </div>
            <div class="clear"></div>
            <div class="footerBar"></div>
        </div>
    </body>
</html>

