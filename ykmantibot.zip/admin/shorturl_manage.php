<?php
// initial constants
define('ADMIN_PAGE_TITLE', 'Manage Urls');
define('ADMIN_SELECTED_PAGE', 'urls');

// includes and security
include_once('_local_auth.inc.php');

// clear any old urls
expireOldUrls();

// page header
include_once('_header.inc.php');

if(isset($_REQUEST['delmulti']))
{
    $del = $_REQUEST['url'];
    $del = is_array($del) ? $del : explode(',', $del);
    if(_CONFIG_DEMO_MODE == true)
    {
        adminFunctions::setError(t("no_changes_in_demo_mode"));
    }
    else
    {
        foreach($del as $delete)
        {
            // Delete URL Stats
            $db->query("DELETE FROM stats WHERE page_title = " . $delete);
            // delete url
            $db->query("DELETE FROM shorturl WHERE id = " . $delete . " LIMIT 1");
        }
        adminFunctions::setSuccess('URL\'s successfully deleted.');
    }
}
// load all users
$sQL = "SELECT id, username AS selectValue FROM users ORDER BY username";
$userDetails = $db->getRows($sQL);

// load all url status
$statusDetails = array('active', 'expired', 'disabled', 'spam');

// defaults
$filterText = '';
if(isset($_REQUEST['filterText']))
{
    $filterText = trim($_REQUEST['filterText']);
}

$filterByStatus = 'active';
if(isset($_REQUEST['filterByStatus']))
{
    $filterByStatus = $_REQUEST['filterByStatus'];
}

$filterByUser = null;
if(isset($_REQUEST['filterByUser']))
{
    $filterByUser = (int) $_REQUEST['filterByUser'];
}

if(isset($_REQUEST['error']))
{
    adminFunctions::setError(urldecode($_REQUEST['error']));
}
?>

<script>
    oTable = null;
    gUrlId = null;
    $(document).ready(function () {
        // datatable
        oTable = $('#urlTable').dataTable({
            "sPaginationType": "full_numbers",
            "bServerSide": true,
            "bProcessing": true,
            "sAjaxSource": 'ajax/shorturl_manage.ajax.php',
            "bJQueryUI": true,
            "iDisplayLength": 25,
            "aaSorting": [[2, "desc"]],
            "aoColumns": [
                {bSortable: false, sWidth: '2%', sClass: "center"},
                {bSortable: false, sWidth: '3%', sName: 'url_icon', sClass: "center"},
                {sName: 'urlname', sWidth: '15%'},
                {sName: 'date_created', sWidth: '10%', sClass: "center"},
                {sName: 'visits', sWidth: '12%', sClass: "center"},
                {sName: 'owner', sWidth: '12%', sClass: "center"},
                {sName: 'last_accessed', sWidth: '18%', sClass: "center"},
                {sName: 'status', sWidth: '12%', sClass: "center"},
                {bSortable: false, sWidth: '25%', sClass: "center"}
            ],
            "fnServerData": function (sSource, aoData, fnCallback) {
                aoData.push({"name": "filterText", "value": $('#filterText').val()});
                aoData.push({"name": "filterByUser", "value": $('#filterByUser').val()});
                aoData.push({"name": "filterByStatus", "value": $('#filterByStatus').val()});
                $.ajax({
                    "dataType": 'json',
                    "type": "GET",
                    "url": "ajax/shorturl_manage.ajax.php",
                    "data": aoData,
                    "success": fnCallback
                });
            }
        });

        // update custom filter
        $('.dataTables_filter').html($('#customFilter').html());

        // dialog box
        $("#confirmDelete").dialog({
            modal: true,
            autoOpen: false,
            width: 800,
            buttons: {
                "Delete Url": function () {
                    removeUrl();
                    $("#confirmDelete").dialog("close");
                },
                "Cancel": function () {
                    $("#confirmDelete").dialog("close");
                }
            },
            open: function () {
                resetOverlays();
            }
        });

        $("#showNotes").dialog({
            modal: true,
            autoOpen: false,
            width: 800,
            buttons: {
                "OK": function () {
                    $("#showNotes").dialog("close");
                }
            },
            open: function () {
                resetOverlays();
            }
        });
    });

    function reloadTable()
    {
        oTable.fnDraw(false);
    }

    function confirmRemoveUrl(urlId)
    {
        $('#confirmDelete').dialog('open');
        gUrlId = urlId;
    }

    function showNotes(notes)
    {
        $('#showNotes').html(notes);
        $('#showNotes').dialog('open');
    }

    $(function () {
        $('#select-all').click(function (event) {
            if (this.checked) {
                $(':checkbox').each(function () {
                    this.checked = true;
                });
            }
            if (!this.checked) {
                $(':checkbox').each(function () {
                    this.checked = false;
                });
            }
        });
    });

    function removeUrl()
    {
        $.ajax({
            type: "POST",
            url: "ajax/update_url_state.ajax.php",
            data: {urlId: gUrlId, status: $('#removal_type').val(), adminNotes: $('#admin_notes').val()},
            dataType: 'json',
            success: function (json) {
                if (json.error == true)
                {
                    showError(json.msg);
                } else
                {
                    showSuccess(json.msg);
                    $('#removal_type').val(3);
                    $('#admin_notes').val('');
                    reloadTable();
                }

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                showError(XMLHttpRequest.responseText);
            }
        });
    }
</script>
<div class="row clearfix">
    <div class="sectionLargeIcon largeUrlIcon"></div>
    <div class="widget clearfix">
        <h2>Url List</h2>
        <div class="widget_inside">
            <?php echo adminFunctions::compileNotifications(); ?>
            <div class="col_12">
                <form action="shorturl_manage.php" method="post" enctype="multipart/form-data" name="delmulti">
                    <table id='urlTable' class='dataTable'>
                        <thead>
                            <tr>
                                <th><div style="padding-top: 7px;"><input type="checkbox" name="select-all" id="select-all"/></div></th>
                                <th></th>
                                <th class="align-left"><?php echo adminFunctions::t('short_url', 'Short Url'); ?></th>
                                <th class="align-left"><?php echo adminFunctions::t('created', 'Created'); ?></th>
                                <th><?php echo adminFunctions::t('visits', 'Visits'); ?></th>
                                <th><?php echo adminFunctions::t('owner', 'Owner'); ?></th>
                                <th><?php echo adminFunctions::t('last_access', 'Last Access'); ?></th>
                                <th><?php echo adminFunctions::t('status', 'Status'); ?></th>
                                <th class="align-left" style="width: 20%;"><?php echo adminFunctions::t('actions', 'Actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>				
            </div>
            <input type="submit" id="delmulti" name="delmulti" value="<?php echo t("delete_selected_urls", "Delete Selected url's"); ?>" onClick="return confirm('Are you sure you want to delete the selected url\'s?');" class="button blue" style="float:left; margin-right:3px;" />
            </form>
            <form action="export_csv.php?type=urls" method="GET">
                <input type="submit" value="Export Url Data (csv)" class="button blue"/>            
            </form>
            </form>
        </div>
    </div>
</div>

<div class="customFilter" id="customFilter" style="display: none;">
    <label>
        Filter Results:
        <input name="filterText" id="filterText" type="text" value="<?php echo adminFunctions::makeSafe($filterText); ?>" onKeyUp="reloadTable();
                return false;" style="width: 160px;"/>
    </label>
    <label style="padding-left: 6px;">
        By User:
        <select name="filterByUser" id="filterByUser" onChange="reloadTable();
                return false;" style="width: 160px;">
            <option value="">- all -</option>
            <?php
            if(COUNT($userDetails))
            {
                foreach($userDetails AS $userDetail)
                {
                    echo '<option value="' . $userDetail['id'] . '"';
                    if(($filterByUser) && ($filterByUser == $userDetail['id']))
                    {
                        echo ' SELECTED';
                    }
                    echo '>' . $userDetail['selectValue'] . '</option>';
                }
            }
            ?>
        </select>
    </label>
    <label style="padding-left: 6px;">
        By Status:
        <select name="filterByStatus" id="filterByStatus" onChange="reloadTable();
                return false;" style="width: 120px;">
            <option value="">- all -</option>
            <?php
            if(COUNT($statusDetails))
            {
                foreach($statusDetails AS $statusDetail)
                {
                    echo '<option value="' . $statusDetail . '"';
                    if(($filterByStatus) && ($filterByStatus == $statusDetail))
                    {
                        echo ' SELECTED';
                    }
                    echo '>' . UCWords($statusDetail) . '</option>';
                }
            }
            ?>
        </select>
    </label>
</div>

<div id="confirmDelete" title="Confirm Action">
    <p>Select the type of removal below. You can also add removal notes such as a copy of the original removal request. The notes are only visible by an admin user.</p>
    <form id="removeUrlForm" class="form">
        <div class="clearfix">
            <label>Removal Type:</label>
            <div class="input">
                <select name="removal_type" id="removal_type" class="xlarge">
                    <option value="disabled">General</option>
                    <option value="spam">Spam</option>
                    <option value="permanent">Delete From Database (permanent removal, all data deleted)</option>
                </select>
            </div>
        </div>
        <div class="clearfix alt-highlight">
            <label>Notes:</label>
            <div class="input">
                <textarea name="admin_notes" id="admin_notes" class="xxlarge"></textarea>
            </div>
        </div>
    </form>
</div>

<div id="showNotes" title="Url Notes"></div>

<?php
include_once('_footer.inc.php');
?>