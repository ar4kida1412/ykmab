<?php
define('ADMIN_PAGE_TITLE', 'Dashboard');
include_once('_local_auth.inc.php');
include_once('_header.inc.php');

// downgrade accounts
UserPeer::downgradeExpiredAccounts();

// load stats
$totalActiveUrls     	= (int) $db->getValue("SELECT COUNT(1) AS total FROM shorturl WHERE status = 'active'");
$totalDisabledUrls     	= (int) $db->getValue("SELECT COUNT(1) AS total FROM shorturl WHERE status != 'active'");
$totalVisits       		= (int) $db->getValue("SELECT SUM(visits) AS total FROM shorturl");
$totalRegisteredUsers 	= (int) $db->getValue("SELECT COUNT(1) AS total FROM users WHERE status='active'");
$newUsers30Days     	= (int) $db->getValue("SELECT COUNT(1) AS total FROM users WHERE datecreated BETWEEN NOW() - INTERVAL 30 DAY AND NOW()");
$newUrls30Days       	= (int) $db->getValue("SELECT COUNT(1) AS total FROM shorturl WHERE dateCreated BETWEEN NOW() - INTERVAL 30 DAY AND NOW()");
?>

<script>
// check for script upgrades
$(document).ready(function(){
    $.ajax({
        url: "ajax/check_for_upgrade.ajax.php",
        dataType: "html"
    }).done(function(response) {
        if(response.length > 0)
        {
            showInfo(response);
        }
    });
	
	loadCharts();
});

function loadCharts()
{
	$('#wrapper_14_day_chart .js_content').load('ajax/_dashboard_chart_14_day_chart.ajax.php', function() {
		$('#wrapper_file_status_chart .js_content').load('ajax/_dashboard_chart_file_status_chart.ajax.php');
	});
	
	$('#wrapper_12_months_chart .js_content').load('ajax/_dashboard_chart_12_months_chart.ajax.php', function() 
	{
		$('#wrapper_file_type_chart .js_content').load('ajax/_dashboard_chart_file_type_chart.ajax.php', function() 
		{
			$('#wrapper_14_day_users .js_content').load('ajax/_dashboard_chart_14_day_users.ajax.php');
		});
	});
}
</script>

<div class="row clearfix">
    <div class="col_12">
        <div class="sectionLargeIcon largeDashboardIcon"></div>
        <div class="widget clearfix">
            <h2><?php echo adminFunctions::t('quick_overview', 'Quick Overview'); ?></h2>
            <div class="widget_inside">
                <h3>Current Statistics</h3>
                <div class="report">
                    <a href="shorturl_manage.php">
                        <div class="button up">
                            <span class="value"><?php echo number_format($totalActiveUrls, 0); ?></span>
                            <span class="attr">Active Urls</span>
                        </div>
                    </a>

                    <a href="shorturl_manage.php">
                        <div class="button up">
                            <span class="value"><?php echo number_format($totalDisabledUrls, 0); ?></span>
                            <span class="attr">Disabled Urls</span>
                        </div>
                    </a>

                    <a href="shorturl_manage.php">
                        <div class="button up">
                            <span class="value"><?php echo number_format($totalVisits, 0); ?></span>
                            <span class="attr">Total Visits (All Urls)</span>
                        </div>
                    </a>
                    
                    <a href="shorturl_manage.php">
                        <div class="button up">
                            <span class="value"><?php echo number_format($newUrls30Days, 0); ?></span>
                            <span class="attr">New Urls (30 Days)</span>
                        </div>
                    </a>

                    <a href="user_manage.php?filterByAccountStatus=active">
                        <div class="button up">
                            <span class="value"><?php echo number_format($totalRegisteredUsers, 0); ?></span>
                            <span class="attr">Total Active Users</span>
                        </div>
                    </a>

                    <a href="user_manage.php">
                        <div class="button up">
                            <span class="value"><?php echo number_format($newUsers30Days, 0); ?></span>
                            <span class="attr">New Users (30 Days)</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row clearfix">
    <div class="col_8">
        <div class="widget clearfix">
            <h2><?php echo adminFunctions::t("dashboard_graph_last_14_days_title", "New Urls (last 14 days)"); ?></h2>
            <div id="wrapper_14_day_chart" class="widget_inside">
				<div id="14_day_chart" style="width:100%; height:300px;" class="centered background-loading"></div>
				<span class="js_content"></span>
			</div>
        </div>
    </div>
    
    <div class="col_4 last">
        <div class="widget">
            <h2><?php echo adminFunctions::t('url_status', 'Url Status'); ?></h2>
            <div id="wrapper_file_status_chart" class="widget_inside">
                <div id="file_status_chart" style="width:100%; height: 300px" class="centered background-loading"></div>
                <div id="file_status_chart_hover" class="pieHoverText"></div>
				<span class="js_content"></span>
            </div>
        </div>
    </div>
</div>

<div class="row clearfix">
    <div class="col_8">
        <div class="widget clearfix">
            <h2><?php echo adminFunctions::t("dashboard_graph_last_12_months_title", "New Urls (last 12 months)"); ?></h2>
            <div id="wrapper_12_months_chart" class="widget_inside">
                <div id="12_months_chart" style="width:100%; height:300px;" class="centered background-loading"></div>
                <span class="js_content"></span>
            </div>
        </div>
    </div>

    <div class="col_4 last">
        <div class="widget">
            <h2><?php echo adminFunctions::t('top_10_urls', 'Top 10 Urls'); ?></h2>
            <div id="wrapper_file_type_chart" class="widget_inside">
                <div id="file_type_chart" style="width:100%; height: 300px" class="centered background-loading"></div>
                <div id="file_type_chart_hover" class="pieHoverText"></div>
                <span class="js_content"></span>
            </div>
        </div>
    </div>
</div>

<div class="row clearfix paid-account-option">
    <div class="col_8">
        <div class="widget clearfix">
            <h2><?php echo adminFunctions::t("dashboard_graph_user_registrations_title", "New Users (last 14 days)"); ?></h2>
            <div id="wrapper_14_day_users" class="widget_inside">
                <div id="14_day_users" style="width:100%; height:300px;" class="centered background-loading"></div>
                <span class="js_content"></span>
            </div>
        </div>
    </div>
</div>

<?php
include_once('_footer.inc.php');
?>