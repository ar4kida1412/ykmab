<?php
// initial constants
define('ADMIN_PAGE_TITLE', 'Manage Url Domains');
define('ADMIN_SELECTED_PAGE', 'url_domains');

// includes and security
include_once('_local_auth.inc.php');

// do deletes
if (isset($_REQUEST['delete']))
{
    // get domain id
    $domainId = (int) $_REQUEST['delete'];

    // make sure the domain is valid
    $rs = $db->getValue("SELECT id FROM url_domain WHERE id = " . (int) $domainId . " AND domain != '[[[main_url]]]' LIMIT 1");
    if ($rs)
    {
        // delete urls and stats, batch to avoid memory issues
        $siteUrls = array(1);
        while (COUNT($siteUrls) > 0)
        {
            $siteUrls = $db->getRows("SELECT id FROM shorturl WHERE urlDomainId = " . (int) $domainId . " LIMIT 1000");
            if ($siteUrls)
            {
                foreach ($siteUrls AS $siteUrl)
                {
                    // stats
                    $db->query("DELETE FROM stats WHERE page_title = " . (int) $siteUrl['id']);

                    // url
                    $db->query("DELETE FROM shorturl WHERE id = " . (int) $siteUrl['id']);
                }
            }
        }

        // delete domain
        $db->query("DELETE FROM url_domain WHERE id = " . (int) $domainId . " AND domain != '[[[main_url]]]' LIMIT 1");

        // success message
        adminFunctions::setSuccess('Domain and any associated short urls deleted.');
    }
    else
    {
        adminFunctions::setError("Could not load domain to delete.");
    }
}

// page header
include_once('_header.inc.php');

// account types
$accountTypeDetails = array('user', 'admin');

// account status
$accountStatusDetails = array('active', 'pending', 'disabled', 'suspended');

// error/success messages
if (isset($_REQUEST['sa']))
{
    adminFunctions::setSuccess('New user successfully added.');
}
elseif (isset($_REQUEST['se']))
{
    adminFunctions::setSuccess('User successfully updated.');
}
elseif (isset($_REQUEST['error']))
{
    adminFunctions::setError(urldecode($_REQUEST['error']));
}

// get any params
$filterByAccountType = '';
if (isset($_REQUEST['filterByAccountType']))
{
    $filterByAccountType = trim($_REQUEST['filterByAccountType']);
}

$filterByAccountStatus = 'active';
if (isset($_REQUEST['filterByAccountStatus']))
{
    $filterByAccountStatus = trim($_REQUEST['filterByAccountStatus']);
}
?>

<script>
    oTable = null;
    gUserId = null;
    $(document).ready(function() {
        // datatable
        oTable = $('#urlTable').dataTable({
            "sPaginationType": "full_numbers",
            "bServerSide": true,
            "bProcessing": true,
            "sAjaxSource": 'ajax/url_domain_manage.ajax.php',
            "bJQueryUI": true,
            "iDisplayLength": 25,
            "aaSorting": [[1, "asc"]],
            "aoColumns": [
                {bSortable: false, sWidth: '3%', sName: 'url_icon', sClass: "center"},
                {sName: 'domain'},
                {sName: 'total_urls', sWidth: '10%', sClass: "center"},
                {sName: 'access_type', sWidth: '16%', sClass: "center"},
                {sName: 'status', sWidth: '10%', sClass: "center"},
                {bSortable: false, sWidth: '15%', sClass: "center"}
            ],
            "fnServerData": function(sSource, aoData, fnCallback) {
                aoData.push({"name": "filterText", "value": $('#filterText').val()});
                $.ajax({
                    "dataType": 'json',
                    "type": "GET",
                    "url": "ajax/url_domain_manage.ajax.php",
                    "data": aoData,
                    "success": fnCallback
                });
            }
        });

        // update custom filter
        $('.dataTables_filter').html($('#customFilter').html());

        // dialog box
        $("#confirmDelete").dialog({
            modal: true,
            autoOpen: false,
            width: 450,
            buttons: {
                "Delete User": function() {
                    removeUser();
                    $("#confirmDelete").dialog("close");
                },
                "Cancel": function() {
                    $("#confirmDelete").dialog("close");
                }
            },
            open: function() {
                resetOverlays();
            }
        });
    });

    function reloadTable()
    {
        oTable.fnDraw(false);
    }

    function confirmRemoveUser(userId)
    {
        $('#confirmDelete').dialog('open');
        gUserId = userId;
    }

    function removeFile()
    {
        $.ajax({
            type: "POST",
            url: "ajax/update_user_state.ajax.php",
            data: {urlId: gUserId, statusId: 3},
            dataType: 'json',
            success: function(json) {
                if (json.error == true)
                {
                    showError(json.msg);
                }
                else
                {
                    showSuccess(json.msg);
                    reloadTable();
                }

            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                showError(XMLHttpRequest.responseText);
            }
        });
    }
</script>

<div class="row clearfix">
    <div class="sectionLargeIcon largeUserIcon"></div>
    <div class="widget clearfix">
        <h2>Manage Short Url Domains</h2>
        <div class="widget_inside">
            <?php echo adminFunctions::compileNotifications(); ?>
            <div class="col_12">
                <table id='urlTable' class='dataTable'>
                    <thead>
                        <tr>
                            <th></th>
                            <th class="align-left"><?php echo adminFunctions::t('domain', 'Domain'); ?></th>
                            <th><?php echo adminFunctions::t('total_urls', 'Total Urls'); ?></th>
                            <th><?php echo adminFunctions::t('access_type', 'Access Type'); ?></th>
                            <th><?php echo adminFunctions::t('status', 'Status'); ?></th>
                            <th class="align-left"><?php echo adminFunctions::t('actions', 'Actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <form action="url_domain_add.php" method="GET">
                <input type="submit" value="Add Short Url Domain" class="button blue"/>
            </form>
        </div>
    </div>
</div>

<div class="customFilter" id="customFilter" style="display: none;">
    <label>
        Filter Results:
        <input name="filterText" id="filterText" type="text" onKeyUp="reloadTable();
        return false;" style="width: 160px;"/>
    </label>
</div>

<div id="confirmDelete" title="Confirm Action">
    <p>Are you sure you want to disable this user?</p>
</div>

<?php
include_once('_footer.inc.php');
?>