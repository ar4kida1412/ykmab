<?php

error_reporting(E_ALL);
// initial constants
define('ADMIN_SELECTED_PAGE', 'urls');

// includes and security
include_once('_local_auth.inc.php');

// load user details
$urlId      = (int) $_REQUEST['id'];
$urlStatus  = array('active', 'expired', 'disabled', 'spam');
$urlRes     = $db->getRow("SELECT shorturl.*, users.username, url_domain.domain AS urlDomain FROM shorturl INNER JOIN url_domain ON shorturl.urlDomainId = url_domain.id INNER JOIN users ON shorturl.userId = users.id WHERE shorturl.id = ". $urlId ." LIMIT 1");

if(!$urlRes)
{
    // Try different query
    $urlNoUid = $db->getRow("SELECT shorturl.*, url_domain.domain AS urlDomain FROM shorturl INNER JOIN url_domain ON shorturl.urlDomainId = url_domain.id WHERE shorturl.id = ". $urlId ." LIMIT 1");
}

if (!$urlRes && !$urlNoUid)
{
    adminFunctions::redirect('shorturl_manage.php?error=' . urlencode('There was a problem loading the url details.'));
}
define('ADMIN_PAGE_TITLE', 'Edit Url');

if($urlRes)
{
    $urlS = $urlRes['status'];
    $urlId = $urlRes['id'];
    $urlDomainId = $urlNoUid['urlDomainId'];
}
else
{
    $urlS = $urlNoUid['status'];
    $urlId = $urlNoUid['id'];
    $urlDomainId = $urlNoUid['urlDomainId'];
}
// handle page submissions
if (isset($_REQUEST['submitted']))
{
    // Get post variables
    $urlId              = (int)$_REQUEST['id'];
    $shortUrl           = $_REQUEST['shortUrl'];
    $redirectsTo        = $_REQUEST['redirectsTo'];
    $urlStat            = $_REQUEST['urlStatus'];
    $deleteStats        = (int) $_REQUEST['deleteStats'];  
    $urlDomainId        = (int) $_REQUEST['urlDomainId']; 
    $originalShortUrl   = $_REQUEST['originalShortUrl']; 
    
    // validate submission
    if (_CONFIG_DEMO_MODE == true)
    {
        adminFunctions::setError(adminFunctions::t("no_changes_in_demo_mode"));
    }
    if(strlen($shortUrl) == 0)
    {        
        adminFunctions::setError(adminFunctions::t("please_enter_a_shortened_url", "Please enter a shortened url."));
    }
    elseif(strlen($redirectsTo) == 0)
    {
        adminFunctions::setError(adminFunctions::t("please_enter_a_url", "Please enter a url."));
    }
    elseif(isValidUrl($redirectsTo) == false)
    {
        adminFunctions::setError(adminFunctions::t("please_enter_a_valid_url", "Please enter a valid url."));
    }

    // Edit the url
    if (adminFunctions::isErrors() == false)
    {
        // update the url
        if($deleteStats == 1)
        {
            $dbUpdate               = new DBObject("shorturl", array("shortUrl", "originalUrl", "visits", "status"), 'id');
            $dbUpdate->shortUrl     = $shortUrl;
            $dbUpdate->originalUrl  = $redirectsTo;
            $dbUpdate->visits       = '0';
            $dbUpdate->status       = $urlStat;
            $dbUpdate->id           = $urlId;
            $dbUpdate->update();            
            $db->query("DELETE FROM stats WHERE page_title = '".$urlId."'");          
        }
        else
        {
            $dbUpdate               = new DBObject("shorturl", array("shortUrl", "originalUrl", "status"), 'id');
            $dbUpdate->shortUrl     = $shortUrl;
            $dbUpdate->originalUrl  = $redirectsTo;
            $dbUpdate->status       = $urlStat;
            $dbUpdate->id           = $urlId;
            $dbUpdate->update();
        }
        // redirect
        adminFunctions::redirect('shorturl_manage.php?se=1');
    }
}

// page header
include_once('_header.inc.php');
?>

<script>
    $(function() {
        // formvalidator
        $("#userForm").validationEngine();
    });
</script>

<div class="row clearfix">
    <div class="col_12">
        <div class="sectionLargeIcon largeUserAddIcon"></div>
        <div class="widget clearfix">
            <h2>Edit Url</h2>
            <div class="widget_inside">
                <?php echo adminFunctions::compileNotifications(); ?>
                <form method="POST" action="shorturl_edit.php?id=<?php echo $urlId; ?>" name="urlForm" id="urlForm" autocomplete="off">
                    <div class="clearfix col_12">
                        <div class="col_4">
                            <h3>Edit Url</h3>
                            <p>Information about the URL.</p>
                        </div>
                        <div class="col_8 last">
                            <div class="form">
                            <div class="clearfix alt-highlight">
                                    <label><?php echo adminFunctions::makeSafe(($urlRes['username'] ? 'Username' : 'IP Address')); ?>:</label>
                                    <div class="input" style="padding-top:6px;">
                                        <?php echo adminFunctions::makeSafe(($urlRes['username'] ? adminFunctions::makeSafe($urlRes['username']) : ($urlNoUid['createdIP'] ? adminFunctions::makeSafe($urlNoUid['createdIP']) : 'No IP Recorded'))); ?>
                                    </div>
                                </div>
                                <div class="clearfix">
                                    <label>Short Url:</label>
                                    <div class="input">
                                        <input type="text" name="shortUrl" value="<?php echo adminFunctions::makeSafe(($urlRes['shortUrl'] ? adminFunctions::makeSafe($urlRes['shortUrl']) : adminFunctions::makeSafe($urlNoUid['shortUrl']))); ?>" class="xxlarge validate[required]" />
                                    </div>
                                </div>
                                <div class="clearfix alt-highlight">
                                    <label>Redirects to:</label>
                                    <div class="input">
                                        <input type="text" name="redirectsTo" value="<?php echo adminFunctions::makeSafe(($urlRes['originalUrl'] ? adminFunctions::makeSafe($urlRes['originalUrl']) : adminFunctions::makeSafe($urlNoUid['originalUrl']))); ?>" class="xxlarge validate[required]" />
                                    </div>
                                </div>
                                <div class="clearfix">
                                    <label>Url Status:</label>
                                    <div class="input">
                                        <select name="urlStatus" id="urlStatus" class="medium validate[required]">
                                            <?php
                                            foreach ($urlStatus AS $status)
                                            {
                                                echo '<option value="' . $status . '"';
                                                if (($urlS) && ($urlS == $status))
                                                {
                                                    echo ' SELECTED';
                                                }
                                                echo '>' . UCWords($status) . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="clearfix alt-highlight">
                                    <label>Delete Stats:</label>
                                    <div class="input">
                                        <select name="deleteStats" id="deleteStats" class="medium validate[required]">
                                            <option value="0" selected="selected">Keep Url Statistics</option>
                                            <option value="1">Delete All Statistics</option>
                                        </select>                                    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="clearfix col_12">
                        <div class="col_4">&nbsp;</div>
                        <div class="col_8 last">
                            <div class="clearfix">
                                <div class="input no-label">
                                    <input type="submit" value="Submit" class="button blue">
                                    <input type="reset" value="Reset" class="button grey">
                                </div>
                            </div>
                        </div>
                    </div>
                    <input name="urlDomainId" type="hidden" value="<?php echo adminFunctions::makeSafe(($urlRes['urlDomainId'] ? adminFunctions::makeSafe($urlRes['urlDomainId']) : adminFunctions::makeSafe($urlNoUid['urlDomainId']))); ?>urlDomainId"/>
                    <input name="submitted" type="hidden" value="1"/>
                    <input name="originalShortUrl" type="hidden" value="<?php echo adminFunctions::makeSafe(($urlRes['shortUrl'] ? adminFunctions::makeSafe($urlRes['shortUrl']) : adminFunctions::makeSafe($urlNoUid['shortUrl']))); ?>"/>
                    <input name="id" type="hidden" value="<?php echo $urlId; ?>"/>
                </form>
            </div>
        </div>   
    </div>
</div>

<?php
include_once('_footer.inc.php');
?>