<?php

// setup includes
require_once('../_local_auth.inc.php');

// prepare the variables
$email = "you@youremail.com";
$subject = "Test email from email_test.php";
$plainMsg = "Test email content";

// send the email using core functions
echo "- Sending email to ".$email." using core script functions... done.<br/>";
send_html_mail($email, "[SCRIPT_MAIL_FUNCTION] ".$subject, $plainMsg, SITE_CONFIG_REPORT_ABUSE_EMAIL, $plainMsg, true);

// send email directly using mail()
echo "- Sending email to ".$email." using PHP mail() function... done.<br/><br/>";
mail($email, "[PHP_MAIL_FUNCTION] ".$subject, $plainMsg);

echo "Script complete. Note: Although this has requested the email to be sent, PHP can not tell if it actually succeeded. You will need to check your inbox for the 2 emails.";