<?php
// initial constants
define('ADMIN_PAGE_TITLE', 'Managed Banned Words');
define('ADMIN_SELECTED_PAGE', 'banned_words');

// includes and security
include_once('_local_auth.inc.php');

// page header
include_once('_header.inc.php');
?>

<script>
    oTable = null;
    gBannedTermId = null;
    $(document).ready(function(){
        // datatable
        oTable = $('#fileTable').dataTable({
            "sPaginationType": "full_numbers",
            "bServerSide": true,
            "bProcessing": true,
            "sAjaxSource": 'ajax/banned_term_manage.ajax.php',
            "bJQueryUI": true,
            "iDisplayLength": 25,
            "aaSorting": [[ 1, "asc" ]],
            "aoColumns" : [   
                { bSortable: false, sWidth: '3%', sName: 'file_icon', sClass: "center" },
                { sName: 'term', sWidth: '25%' },
                { sName: 'date_banned', sWidth: '12%', sClass: "center" },
                { sName: 'ban_notes' },
                { bSortable: false, sWidth: '10%', sClass: "center" }
            ],
            "fnServerData": function ( sSource, aoData, fnCallback ) {
                aoData.push( { "name": "filterText", "value": $('#filterText').val() } );
                $.ajax({
                    "dataType": 'json',
                    "type": "GET",
                    "url": "ajax/banned_term_manage.ajax.php",
                    "data": aoData,
                    "success": fnCallback
                });
            }
        });
        
        // update custom filter
        $('.dataTables_filter').html($('#customFilter').html());

        // dialog box
        $( "#addTermForm" ).dialog({
            modal: true,
            autoOpen: false,
            width: 800,
            height: 440,
            buttons: {
                "Ban Term": function() {
                    processBanTerm();
                },
                "Cancel": function() {
                    $("#addTermForm").dialog("close");
                }
            },
            open: function() {
                setLoader();
                loadAddTermForm();
                resetOverlays();
            }
        });
        
        // dialog box
        $( "#confirmDelete" ).dialog({
            modal: true,
            autoOpen: false,
            width: 450,
            buttons: {
                "Delete Banned Term": function() {
                    removeBannedTerm();
                    $("#confirmDelete").dialog("close");
                },
                "Cancel": function() {
                    $("#confirmDelete").dialog("close");
                }
            }
        });
    });
    
    function setLoader()
    {
        $('#banTermForm').html('Loading, please wait...');
    }
    
    function loadAddTermForm()
    {
        $.ajax({
            type: "POST",
            url: "ajax/banned_term_manage_add_form.ajax.php",
            data: { },
            dataType: 'json',
            success: function(json) {
                if(json.error == true)
                {
                    $('#banTermForm').html(json.msg);
                }
                else
                {
                    $('#banTermForm').html(json.html);
                }
                
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('#banTermForm').html(XMLHttpRequest.responseText);
            }
        });
    }
    
    function processBanTerm()
    {
        // get data
        banned_term = $('#banned_term').val();
        ban_notes = $('#ban_notes').val();
        
        $.ajax({
            type: "POST",
            url: "ajax/banned_term_manage_add_process.ajax.php",
            data: { banned_term: banned_term, ban_notes: ban_notes },
            dataType: 'json',
            success: function(json) {
                if(json.error == true)
                {
                    showError(json.msg, 'popupMessageContainer');
                }
                else
                {
                    showSuccess(json.msg);
                    reloadTable();
                    $("#addTermForm").dialog("close");
                }
                
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                showError(XMLHttpRequest.responseText, 'popupMessageContainer');
            }
        });

    }
    
    function addTermForm()
    {
        $('#addTermForm').dialog('open');
    }

    function reloadTable()
    {
        oTable.fnDraw(false);
    }
    
    function deleteBannedTerm(bannedTermId)
    {
        $('#confirmDelete').dialog('open');
        gBannedTermId = bannedTermId;
    }
    
    function removeBannedTerm()
    {
        $.ajax({
            type: "POST",
            url: "ajax/banned_term_manage_remove.ajax.php",
            data: { bannedTermId: gBannedTermId },
            dataType: 'json',
            success: function(json) {
                if(json.error == true)
                {
                    showError(json.msg);
                }
                else
                {
                    showSuccess(json.msg);
                    reloadTable();
                }
                
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                showError(XMLHttpRequest.responseText);
            }
        });
    }
</script>

<div class="row clearfix">
    <div class="sectionLargeIcon largeBannedTermIcon"></div>
    <div class="widget clearfix">
        <h2>Banned Terms</h2>
        <div class="widget_inside">
            <?php echo adminFunctions::compileNotifications(); ?>
            <div class="col_12">
                <table id='fileTable' class='dataTable'>
                    <thead>
                        <tr>
                            <th></th>
                            <th class="align-left"><?php echo adminFunctions::t('term', 'Term'); ?></th>
                            <th class="align-left"><?php echo adminFunctions::t('date_banned', 'Date Banned'); ?></th>
                            <th class="align-left"><?php echo adminFunctions::t('ban_notes', 'Ban Notes'); ?></th>
                            <th class="align-left"><?php echo adminFunctions::t('actions', 'Actions'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <input type="submit" value="Ban Words/Urls" class="button blue" onClick="addTermForm(); return false;"/>
        </div>
    </div>
</div>

<div class="customFilter" id="customFilter" style="display: none;">
    <label>
        Filter Results:
        <input name="filterText" id="filterText" type="text" onKeyUp="reloadTable(); return false;" style="width: 160px;"/>
    </label>
</div>

<div id="addTermForm" title="Ban Words/Urls">
    <span id="banTermForm"></span>
</div>

<div id="confirmDelete" title="Confirm Action">
    <p>Are you sure you want to delete this banned term?</p>
</div>

<?php
include_once('_footer.inc.php');
?>