<?php

// allow for 10 minutes for the export
set_time_limit(60 * 10);

// load security
require_once('_local_auth.inc.php');

/* resulting csv data */
$formattedCSVData = array();

/* header */
$lArr = array();
$lArr[]             = "Id";
$lArr[]             = "Short Url";
$lArr[]             = "Original Url";
$lArr[]             = "Created Date";
$lArr[]             = "Created IP";
$lArr[]             = "Visits";
$lArr[]             = "Access Password";
$lArr[]             = "Expires";
$lArr[]             = "Available Uses";
$lArr[]             = "Last Accessed";
$lArr[]             = "Status";
$formattedCSVData[] = "\"" . implode("\",\"", $lArr) . "\"";

/* get all url data */
$urlData = $db->getRows("SELECT * FROM shorturl ORDER BY dateCreated asc");
foreach ($urlData AS $row)
{
    $lArr = array();
    $lArr[] = $row['id'];
    $lArr[] = WEB_ROOT . "/" . $row['shortUrl'];
    $lArr[] = $row['originalUrl'];
    $lArr[] = dater($row['dateCreated']);
    $lArr[] = $row['createdIP'];
    $lArr[] = $row['visits'];
    $lArr[] = $row['password'];
    $lArr[] = ($row['expiryDate'] != "0000-00-00 00:00:00") ? dater($row['expiryDate']) : "";
    $lArr[] = $row['totalUses'];
    $lArr[] = ($row['lastAccessed'] != "0000-00-00 00:00:00") ? dater($row['lastAccessed']) : "";
    $lArr[] = $row['status'];

    $formattedCSVData[] = "\"" . implode("\",\"", $lArr) . "\"";
}

$outname = "url_data.csv";
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Content-type: text/plain;");
header("Content-Transfer-Encoding: binary;");
header("Content-Disposition: attachment; filename=\"$outname\";");

echo implode("\n", $formattedCSVData);
exit;