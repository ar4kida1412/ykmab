<?php
// initial constants
define('ADMIN_SELECTED_PAGE', 'url_domains');

// includes and security
include_once('_local_auth.inc.php');

// load domain details
$domainId  = (int) $_REQUEST['id'];
$domainRow = $db->getRow("SELECT * FROM url_domain WHERE id = " . (int) $domainId . " LIMIT 1");
if (!$domainRow)
{
    adminFunctions::redirect('url_domain_manage.php?error=' . urlencode('There was a problem loading the domain details.'));
}
define('ADMIN_PAGE_TITLE', 'Edit Domain: \'' . str_replace("[[[main_url]]]", _CONFIG_SITE_HOST_URL, $domainRow['domain']) . '\'');

// status
$statusDetails = array('enabled', 'read only', 'disabled');

// prepare variables
$domain       = str_replace("[[[main_url]]]", _CONFIG_SITE_HOST_URL, $domainRow['domain']);
$premium_only = $domainRow['premium_only'];
$status       = $domainRow['status'];

// handle page submissions
if (isset($_REQUEST['submitted']))
{
    // get variables
    $premium_only = (int) $_REQUEST['premium_only'];
    $status       = trim($_REQUEST['status']);

    // validate submission
    if (_CONFIG_DEMO_MODE == true)
    {
        adminFunctions::setError(adminFunctions::t("no_changes_in_demo_mode"));
    }

    // add the account
    if (adminFunctions::isErrors() == false)
    {
        // update record
        $dbUpdate               = new DBObject("url_domain", array("premium_only", "status", "date_created"), 'id');
        $dbUpdate->premium_only = $premium_only;
        $dbUpdate->status       = $status;
        $dbUpdate->date_created = sqlDateTime();
        $dbUpdate->id           = $domainId;
        $dbUpdate->update();

        // redirect
        adminFunctions::redirect('url_domain_manage.php?se=1');
    }
}

// page header
include_once('_header.inc.php');
?>

<script>
    $(function() {
        // formvalidator
        $("#userForm").validationEngine();
    });
</script>

<div class="row clearfix">
    <div class="col_12">
        <div class="sectionLargeIcon largeUserAddIcon"></div>
        <div class="widget clearfix">
            <h2>User Details</h2>
            <div class="widget_inside">
                <?php echo adminFunctions::compileNotifications(); ?>
                <form method="POST" action="url_domain_edit.php" name="userForm" id="userForm">
                    <div class="clearfix col_12">
                        <div class="col_4">
                            <h3>Short Url Domain Details</h3>
                            <p>Enter the details of the short url domain name.</p>
                        </div>
                        <div class="col_8 last">
                            <div class="form">
                                <div class="clearfix alt-highlight">
                                    <label>Domain Name:</label>
                                    <div class="input" style="margin-top: 5px;">
                                        <?php echo adminFunctions::makeSafe($domain); ?>
                                    </div>
                                </div>
                                <div class="clearfix">
                                    <label>Who Can Access:</label>
                                    <div class="input">
                                        <select name="premium_only" id="premium_only" class="large validate[required]">
                                            <option value="0" <?php echo($premium_only == 0) ? 'SELECTED' : ''; ?>>All Users</option>
                                            <option value="1" <?php echo($premium_only == 1) ? 'SELECTED' : ''; ?>>Registered Users</option>
                                            <!--<option value="2" <?php echo($premium_only == 2) ? 'SELECTED' : ''; ?>>Only Paid Users</option>-->
                                        </select>
                                    </div>
                                </div>
                                <div class="clearfix alt-highlight">
                                    <label>Status:</label>
                                    <div class="input">
                                        <select name="status" id="status" class="large validate[required]">
                                            <?php foreach ($statusDetails AS $statusDetail): ?>
                                                <option value="<?php echo $statusDetail; ?>" <?php echo($status == $statusDetail) ? 'SELECTED' : ''; ?> ><?php echo UCWords($statusDetail); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <?php if($domainRow['domain'] != '[[[main_url]]]'): ?>
                    <div class="clearfix col_12">
                        <div class="col_4">
                            <h3>Redirect Code</h3>
                            <p>So that the url redirects work, ensure your have mod_rewrite enabled on your new domain. Then copy this code into a new file called '.htaccess' in the folder of the domain above.</p>
                        </div>
                        <div class="col_8 last">
                            <div class="form">
                                <pre style="border: none; margin: 15px; font-size: 10px; box-shadow: none;">RewriteEngine On
RewriteCond %{REQUEST_URI} ^(.+)\~s$
RewriteRule ^(.*) <?php echo WEB_ROOT; ?>/stats.php?url=$1 [L]
RewriteCond %{REQUEST_URI} ^(.+)\~q$
RewriteRule ^(.*) <?php echo WEB_ROOT; ?>/generate_qr.php?url=$1 [L]
RewriteCond %{REQUEST_URI} ^(.+)\~p$
RewriteRule ^(.*) <?php echo WEB_ROOT; ?>/preview_url.php?url=$1 [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*) <?php echo WEB_ROOT; ?>/url_redirector.php?url=$1 [L]</pre>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="clearfix col_12">
                        <div class="col_4">&nbsp;</div>
                        <div class="col_8 last">
                            <div class="clearfix">
                                <div class="input no-label">
                                    <input type="submit" value="Submit" class="button blue">
                                    <input type="reset" value="Reset" class="button grey">
                                </div>
                            </div>
                        </div>
                    </div>

                    <input name="submitted" type="hidden" value="1"/>
                    <input name="id" type="hidden" value="<?php echo (int) $domainId; ?>"/>
                </form>
            </div>
        </div>   
    </div>
</div>

<?php
include_once('_footer.inc.php');
?>