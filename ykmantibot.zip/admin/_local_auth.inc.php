<?php
// Determine our absolute document root
define('ADMIN_ROOT', realpath(dirname(__FILE__)));

// global includes
require_once(ADMIN_ROOT.'/../includes/master.inc.php');
require_once(ADMIN_ROOT.'/_admin_functions.inc.php');
if(!defined('ADMIN_IGNORE_LOGIN'))
{
    $Auth->requireAdmin();
    $userObj = $Auth->getAuth();
}

// setup database
$db = Database::getDatabase();