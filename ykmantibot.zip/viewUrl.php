<?php
/* setup includes */
require_once('includes/master.inc.php');

/* we expect to receive a param on this page, it not, throw an error */
$u = $_REQUEST['u'];
if (!$u)
{
    setError(t("no_valid_url_found"));
}

if (isErrors())
{
    require_once('_header.php');
    ?>
    <div class="searchBoxWrapper">
        <?php
        echo outputErrors();
        ?>
    </div>
    <?php
    require_once('_footer.php');
}
else
{
    redirect(WEB_ROOT . "/index." . SITE_CONFIG_PAGE_EXTENSION . "?u=" . $u . "&success=1");
}
