<div class="row">
    <div class="span4">
        <i class="fa account-benefits fa-check">&nbsp;</i><?php echo t('direct_urls_no_waiting', 'Direct urls. No waiting.'); ?>
        <div class="clear"></div>
        <i class="fa account-benefits fa-check">&nbsp;</i><?php echo t('no_advertising', 'No advertising.'); ?>
        <div class="clear"></div>
        <i class="fa account-benefits fa-check">&nbsp;</i><?php echo t('no_account_restrictions', 'No account restrictions.'); ?>
    </div>
    <div class="span4">
        <i class="fa account-benefits fa-check">&nbsp;</i><?php echo t('no_limitations_on_daily_url_volume', 'No limitations on daily url creation.'); ?>
		<div class="clear"></div>
        <i class="fa account-benefits fa-check">&nbsp;</i><?php echo t('priority_support', 'Priority support.'); ?>
        <div class="clear"></div>
        <i class="fa account-benefits fa-check">&nbsp;</i><?php echo t('unlimited_urls', 'Unlimited urls.'); ?>
    </div>
    <div class="span4">
        <i class="fa account-benefits fa-check">&nbsp;</i><?php echo t('no_limits_on_the_amount_of_users', 'No limits on the amount of users.'); ?>
        <div class="clear"></div>
        <i class="fa account-benefits fa-check">&nbsp;</i><?php echo t('low_price_per_day', 'Low price per day.'); ?>
        <div class="clear"></div>
        <i class="fa account-benefits fa-check">&nbsp;</i><?php echo t('no_subscriptions', 'No subscriptions.'); ?>
    </div>
</div>