<?php
/* setup includes */
require_once('includes/master.inc.php');

/* setup page */
define("PAGE_NAME", t("login_page_name", "Login"));
define("PAGE_DESCRIPTION", t("login_meta_description", "Login to your account"));
define("PAGE_KEYWORDS", t("login_meta_keywords", "login, register, short url"));
define("SITE_SELECTED_PAGE", "login");

/* register user */
if ((int) $_REQUEST['submitme'])
{
    // do login
    $loginUsername = trim($_REQUEST['loginUsername']);
    $loginPassword = trim($_REQUEST['loginPassword']);

    if (!strlen($loginUsername))
    {
        setError(t("please_enter_your_username", "Please enter your username"));
    }
    elseif (!strlen($loginPassword))
    {
        setError(t("please_enter_your_password", "Please enter your password"));
    }
    else
    {
        $rs = $Auth->login($loginUsername, $loginPassword);
        if ($rs)
        {
            // successful login
            redirect(WEB_ROOT . '/account_home.html');
        }
        else
        {
            // login failed
            setError(t("username_and_password_is_invalid", "Your username and password are invalid"));
        }
    }
}

require_once('_header.php');
?>

<div class="span9 page_sidebar">
    <?php
    if (isErrors())
    {
        echo outputErrors();
    }
    ?>
    <div class="well">
        <h5><?php echo t("account_login", "Account Login"); ?></h5>
        <hr/>
        <p>
            <?php echo t("login_intro_text", "Please enter your username and password below to login."); ?>
        </p>
        <form method="post" action="<?php echo WEB_ROOT; ?>/login.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>" class="form" AUTOCOMPLETE="off">
            <div>
                <label for="loginUsernameMain">
                    <?php echo t("username", "username"); ?>
                </label>
                <input type="text" tabindex="1" value="<?php echo isset($loginUsername) ? safeOutputToScreen($loginUsername, 'abcdefghijklmnopqrstuvwxyz1234567890_') : ''; ?>" id="loginUsernameMain" name="loginUsername">
            </div>

            <div>
                <label for="loginPasswordMain">
                    <?php echo t("password", "password"); ?>
                </label>
                <input type="password" tabindex="2" value="" id="loginPasswordMain" name="loginPassword"></label>
            </div>
            <div class="clear"></div>

            <div class="buttonWrapper">
                <button type="submit" name="submit" class="btn btn-primary" tabindex="99"><?php echo t("login", "login"); ?></button>
            </div>
            <div class="clear"></div>

            <input type="hidden" value="1" name="submitme"/>

            <div class="footerLinkWrapper">
                <ul>
                    <li><a href="<?php echo WEB_ROOT; ?>/forgot_password.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>">Forgot Password?</a></li>
                </ul>
            </div>
        </form>
    </div>
	
	<div class="clear"></div>
                
	<?php
	// include any plugin includes
	pluginHelper::includeAppends('login_login_box.php');
	?>
</div>

<?php include_once("_bannerRightContent.inc.php"); ?>

<?php
require_once('_footer.php');
?>