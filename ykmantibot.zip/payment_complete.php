<?php
/* setup includes */
require_once('includes/master.inc.php');

/* setup page */
define("PAGE_NAME", t("payment_page_name", "Payment Complete"));
define("PAGE_DESCRIPTION", t("payment_meta_description", "Payment complete"));
define("PAGE_KEYWORDS", t("payment_meta_keywords", "payment"));

require_once('_header.php');
?>

<div class="span12">
    <?php
    if (isErrors())
    {
        echo outputErrors();
    }
    ?>
    <div class="faq">
        <?php
        echo t('payment_page_content', '<strong>Thanks for your payment!</strong><br/><br/>Your account will be upgraded to premium within the next 10 minutes. If you have any issues, please try logging out and back into the site. Alternatively free to contact us via the \'contact\' link at the bottom of the site.');
        ?>
        <div class="clear"></div>
		<br/><br/>
    </div>
</div>

<?php
require_once('_footer.php');
?>