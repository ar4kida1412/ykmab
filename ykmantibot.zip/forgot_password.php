<?php
/* setup includes */
require_once('includes/master.inc.php');

/* setup page */
define("PAGE_NAME", t("forgot_password_page_name", "Forgot Password"));
define("PAGE_DESCRIPTION", t("forgot_password_meta_description", "Forgot account password"));
define("PAGE_KEYWORDS", t("forgot_password_meta_keywords", "forgot, password, account, short, url, user"));
define("SITE_SELECTED_PAGE", "login");

/* register user */
if ((int) $_REQUEST['submitme'])
{
    // validation
    $emailAddress = trim(strtolower($_REQUEST['emailAddress']));
    if (!strlen($emailAddress))
    {
        setError(t("please_enter_your_email_address", "Please enter the account email address"));
    }
    else
    {
        $checkEmail = UserPeer::loadUserByEmailAddress($emailAddress);
        if (!$checkEmail)
        {
            // username exists
            setError(t("account_not_found", "Account with that email address not found"));
        }
    }

    // create the account
    if (!isErrors())
    {
        $userAccount = UserPeer::loadUserByEmailAddress($emailAddress);
        if ($userAccount)
        {
            // create password reset hash
            $resetHash = UserPeer::createPasswordResetHash($userAccount->id);

            $subject  = "Password reset instructions for account on " . SITE_CONFIG_SITE_NAME;
            $defaultContent = "Dear [[[FIRSTNAME]]],<br/><br/>";
            $defaultContent .= "We've a request to reset your password on [[[SITE_CONFIG_SITE_NAME]]]. Follow the url below to set a new account password:<br/><br/>";
            $defaultContent .= "<a href='[[[WEB_ROOT]]]/forgot_password_reset.[[[SITE_CONFIG_PAGE_EXTENSION]]]?u=[[[ACCOUNT_ID]]]&h=[[[RESET_HASH]]]'>[[[WEB_ROOT]]]/forgot_password_reset.[[[SITE_CONFIG_PAGE_EXTENSION]]]?u=[[[ACCOUNT_ID]]]&h=[[[RESET_HASH]]]</a><br/><br/>";
            $defaultContent .= "If you didn't request a password reset, just ignore this email and your existing password will continue to work.<br/><br/>";
            $defaultContent .= "Regards,<br/>";
            $defaultContent .= "[[[SITE_CONFIG_SITE_NAME]]] Admin";
            
            $replacements = array();
            $replacements['ACCOUNT_ID'] = $userAccount->id;
            $replacements['RESET_HASH'] = $resetHash;
            $replacements['WEB_ROOT'] = WEB_ROOT;
            $replacements['SITE_CONFIG_SITE_NAME'] = SITE_CONFIG_SITE_NAME;
            $replacements['FIRSTNAME'] = $userAccount->firstname;
            $replacements['SITE_CONFIG_PAGE_EXTENSION'] = SITE_CONFIG_PAGE_EXTENSION;
            
            $htmlMsg = t('forgot_password_email_content', $defaultContent, $replacements);

            send_html_mail($emailAddress, $subject, $htmlMsg, SITE_CONFIG_DEFAULT_EMAIL_ADDRESS_FROM, strip_tags(str_replace("<br/>", "\n", $plainMsg)));
            redirect(WEB_ROOT . "/forgot_password." . SITE_CONFIG_PAGE_EXTENSION . "?s=1");
        }
    }
}

require_once('_header.php');
?>

<div class="span9 page_sidebar">
    <?php
    if (isErrors())
    {
        echo outputErrors();
    }
    ?>
    <div class="well">
        <h5><?php echo t("forgot_password", "forgot password"); ?></h5>
        <hr/>
        <?php if (isset($_REQUEST['s'])): ?>
            <p>
                <?php echo t("forgot_password_sent_intro_text", "An email has been sent with further instructions on how to reset your password. Please check your email inbox."); ?>
            </p>
        <?php else: ?>
            <p>
                <?php echo t("forgot_password_intro_text", "Enter your email address below to receive further instructions on how to reset your account password."); ?>
            </p>
            <form method="post" action="<?php echo WEB_ROOT; ?>/forgot_password.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>" class="form">
                <div>
                    <label for="emailAddress">
                        <?php echo t("email_address", "email address"); ?>
                    </label>
                    <input type="text" tabindex="1" value="<?php echo isset($emailAddress) ? safeOutputToScreen($emailAddress) : ''; ?>" id="emailAddress" name="emailAddress">
                </div>

                <div class="buttonWrapper">
                    <button type="submit" name="submit" class="btn btn-primary" tabindex="99"><?php echo t("request_reset", "request reset"); ?></button>
                </div>
                <div class="clear"></div>

                <input type="hidden" value="1" name="submitme"/>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php include_once("_bannerRightContent.inc.php"); ?>

<?php
require_once('_footer.php');
?>