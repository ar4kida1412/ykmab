<script>
    $=jQuery;
    $(document).ready(function($) {
        $("#shortUrlExpiryDate").datepicker({
            minDate: 0,
            dateFormat: 'dd-mm-yy'
        });
    });

    $("#longUrl").ready(function($) {
        $("#longUrl").height("60px");
        $("#longUrl").focus();
        $("#longUrl").autosize();
    });

    /* calendar js */
    var cal_obj2 = null;
    var format = '<?php echo strlen(SITE_CONFIG_DATE_TIME_FORMAT_JS) ? str_replace("/", "-", SITE_CONFIG_DATE_TIME_FORMAT_JS) : "%d-%m-%Y %H:%i"; ?>';

    // user defined onchange handler
    function cal2_on_change(cal, object_code)
    {
        if (object_code == 'day')
        {
            document.getElementById("shortUrlExpiryDate").value = cal.get_formatted_date(format);
            cal.hide();
            cal_obj2 = null;
        }
    }
</script>

