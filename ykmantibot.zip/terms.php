<?php
/* setup includes */
require_once('includes/master.inc.php');

/* setup page */
define("PAGE_NAME", t("terms_page_name", "Terms"));
define("PAGE_DESCRIPTION", t("terms_meta_description", "Terms"));
define("PAGE_KEYWORDS", t("terms_meta_keywords", "terms"));

require_once('_header.php');
?>

<div class="span12">
    <?php
    if (isErrors())
    {
        echo outputErrors();
    }
    ?>
    <div class="faq">
        <?php
        echo t('terms_page_content', '<ol><li>Users of this website (Users) agree to be bound by these terms and conditions, which are subject to change at the sole discretion of the site. Your use of and access to this site indicate your acceptance of these terms and conditions.</li><li>This site was created as a free service to make posting long URLs easier. This service is provided without warranty of any kind. Short URLs used in spam (including email and forum spam) will be disabled.</li><li>This site may include third party content which is subject to that third party\'s terms and conditions of use.</li><li>This site may include links to third party sites which are not related to this site and in relation to which we have no control or interest. The appearance of those links on this site does not indicate any relationship between this site and that third party or any endorsement by this site of that third party, its site or the products or services which it is advertising on this site.</li><li>We may use third-party advertising companies to serve ads when you visit our Web site. These companies may use information (not including your name, address email address or telephone number) about your visits to this and other Web sites in order to provide advertisements about goods and services of interest to you. If you would like more information about this practice and to know your choices about not having this information used by these companies, <a href="http://www.google.com/privacy.html" target="_blank">click here</a>.</li><li>This site will have no responsibility or liability in relation to any loss or damage which you incur, including damage to your software or hardware, arising from your use of or access to this site.</li><li>Users will not use this site for any purpose or in any way which is unlawful.</li></ol>');
        ?>
        <div class="clear"></div>
    </div>
</div>

<?php
require_once('_footer.php');
?>