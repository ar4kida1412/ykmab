<?php

/* setup includes */
require_once('includes/master.inc.php');

/* require login */
$Auth->requireUser('login.php');

// setup initial params
$s = (int)$_REQUEST['iDisplayStart'];
$l = (int)$_REQUEST['iDisplayLength'];
$sortCol = (int)$_REQUEST['iSortCol_0'];
$sortDir = $_REQUEST['sSortDir_0']=='asc'?'asc':'desc';
$sSearch = trim($_REQUEST['filterText']);

$db = Database::getDatabase(true);
$clause = "WHERE user_id = " . (int)$Auth->id;
if(strlen($sSearch))
{
    $clause .= " AND (folder_name LIKE '%".$db->escape($sSearch)."%')";
}

// get file total for this account and filter
$allUrls = $db->getValue('SELECT COUNT(id) AS total FROM shorturl_folder '.$clause);

// load limited page filtered
$folders = $db->getRows('SELECT shorturl_folder.*, (SELECT COUNT(id) AS total FROM shorturl WHERE shorturl.shortUrlFolder = shorturl_folder.id) AS total_urls FROM shorturl_folder '.$clause.' ORDER BY folder_name '.$sortDir.' LIMIT '.$s.','.$l);

$data = array();
if ($folders)
{
    foreach ($folders AS $folder)
    {
        $lrs = array();
        $lrs[] = '<img src="'.SITE_IMAGE_PATH.'/folder.png" width="16" height="16"/>';
        $lrs[] = '<a href="http://' . _CONFIG_SITE_FULL_URL . '/account_home.'.SITE_CONFIG_PAGE_EXTENSION.'?filterByFolder=' . $folder['id'] . '">'.$folder['folder_name'].'</a>';
        $lrs[] = $folder['total_urls'];

        $links = array();
        $links[] = '<a href="http://' . _CONFIG_SITE_FULL_URL . '/account_home.'.SITE_CONFIG_PAGE_EXTENSION.'?filterByFolder=' . $folder['id'] . '"><img src="' . SITE_IMAGE_PATH . '/view.png" width="16" height="16" title="'.t('view_urls', 'view urls').'" style="margin-right: 1px;"/></a>';
        $links[] = '<a href="http://' . _CONFIG_SITE_FULL_URL . '/account_folder.' . SITE_CONFIG_PAGE_EXTENSION . '?d=' . $folder['id'] . '" onClick="return confirm(\''.t('are_you_sure_you_want_to_delete_this_folder', 'Are you sure you want to permanently delete this folder? Any short urls associated with this folder will remain in your account but will not longer be assigned to any folder.').'\');"><img src="' . SITE_IMAGE_PATH . '/delete.png" width="16" height="16" title="'.t('delete_folder', 'delete folder').'" style="margin-left: 1px"/></a>';
        $lrs[]   = implode("&nbsp;", $links);

        $data[] = $lrs;
    }
}

// create json response
$result = array();
$result['sEcho']                = intval($_GET['sEcho']);
$result['iTotalRecords']        = $allUrls;
$result['iTotalDisplayRecords'] = $allUrls;
$result['aaData']               = $data;

echo json_encode($result);