<div class="well">
	<h5><?php echo t('account_tools', 'Account Tools'); ?></h5>
	<hr>
	<ul>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/bookmarklet.html"><?php echo UCWords(t('browser_bookmarklet', 'Browser Bookmarklet')); ?></a>
		</li>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/convert_html_links.html"><?php echo UCWords(t('batch_convert_links_in_html', 'Batch Convert Links In HTML')); ?></a>
		</li>
		<?php if (SITE_CONFIG_ENABLE_API == 'yes'): ?>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/api.html"><?php echo UCWords(t('short_url_api', 'Short Url API')); ?></a>
		</li>
		<?php endif; ?>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/export_url_data.php"><?php echo t('export_url_data', 'export url data'); ?></a>
		</li>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/faq.html"><?php echo strtoupper(t('faq', 'faq')); ?></a>
		</li>
	</ul>
</div>

<?php if (SITE_CONFIG_ENABLE_API == 'yes'): ?>
<div class="well">
	<h5><?php echo t('api_usage', 'API Usage'); ?></h5>
	<hr>
	<ul>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/api.html#createBasic"><?php echo UCWords(t('create', 'Create')); ?></a>
		</li>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/api.html#createOptions"><?php echo UCWords(t('create_additional_options', 'Create (Additional Options)')); ?></a>
		</li>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/api.html#disable"><?php echo UCWords(t('disable', 'Disable')); ?></a>
		</li>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/api.html#activate"><?php echo UCWords(t('activate', 'Activate')); ?></a>
		</li>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/api.html#info"><?php echo UCWords(t('info', 'Info')); ?></a>
		</li>
		<li>
			<a href="<?php echo WEB_ROOT; ?>/api.html#list"><?php echo UCWords(t('list', 'List')); ?></a>
		</li>
	</ul>
</div>
<?php endif; ?>