<?php
/* setup includes */
require_once('includes/master.inc.php');

/* setup page */
define("PAGE_NAME", t("delayed_redirect_page_name"));
define("PAGE_DESCRIPTION", t("delayed_redirect_meta_description"));
define("PAGE_KEYWORDS", t("delayed_redirect_meta_keywords"));

/* we expect to receive a param on this page, it not, throw an error */
$shortUrlObj = shortUrl::loadByID($u);

require_once('_header.php');
?>

<script>
    $=jQuery;
    var milisec = 0;
    var seconds = <?php echo (int) SITE_CONFIG_REDIRECT_DELAY_SECONDS; ?>;

    function display()
    { 
        if (milisec<=0)
        {
            milisec	= 9;
            seconds	-= 1;
        }
        if (seconds<=-1)
        {
            milisec = 0;
            seconds += 1;
        } 
        else
        {
            milisec -= 1;
        }
        if(seconds == 0)
        {
            $("#countDownTimer").html("redirecting");
            window.location = "<?php echo safeOutputToScreen($shortUrlObj->fullUrl); ?>";

        }
        else
        {
            $("#countDownTimer").html(seconds+" second");
            if(seconds != 1)
            {
                document.getElementById("countDownTimer").innerHTML += "s";
            }
            setTimeout("display()", 100);
        }
    }

    $(document).ready(function($) {
        $("#countDownTimer").html('30');
        display();
    });
</script>

<div class="span12">
    <div class="center">
        <!-- top ads -->
        <?php echo SITE_CONFIG_ADVERT_DELAYED_REDIRECT_TOP; ?>
        <div class="clear"></div>

        <div class="services" style="margin: 14px;">
            <h3><?php echo t("redirecting_to"); ?> <?php echo safeOutputToScreen($shortUrlObj->getFormattedLongUrl(50)); ?></h3>
            <img src="<?php echo SITE_IMAGE_PATH; ?>/pleaseWait.gif" alt="<?php echo t("please_wait"); ?>" width="50" height="50" style="padding-top: 8px; padding-bottom: 24px;"/>
            <div class="clear"></div>
            (<span id="countDownTimer"><!-- --></span>)
        </div>

        <!-- bottom ads -->
        <?php echo SITE_CONFIG_ADVERT_DELAYED_REDIRECT_BOTTOM; ?>
        <div class="clear"></div>
        <hr/>
    </div>
</div>

<?php
require_once('_footer.php');
?>