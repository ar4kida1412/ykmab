<?php

/* setup includes */
require_once('includes/master.inc.php');
require_once('includes/class.favicon.php');

$id = (int) $_REQUEST['id'];
if (!$id)
{
    outputFailureImage();
}

$shortUrl = shortUrl::loadById($id);
if (!$shortUrl)
{
    outputFailureImage();
}

$favicon = new favicon(shortUrl::getFavIconUrl($shortUrl->fullUrl), 0);
$fv = $favicon->get_output_data();
if ($fv !== '')
{
    header('Content-type: image/png');
    echo $fv;
}
else
{
    outputFailureImage();
}