<?php
/* setup includes */
require_once('includes/master.inc.php');

/* setup page */
define("PAGE_NAME", t("report_url_page_name"));
define("PAGE_DESCRIPTION", t("report_url_meta_description"));
define("PAGE_KEYWORDS", t("report_url_meta_keywords"));

/* send report if submitted */
if ((int) $_REQUEST['submitme'])
{
    if (!strlen($_REQUEST['problemUrl']))
    {
        setError(t("report_url_error_no_url", "Please enter the problem url."));
    }
    else
    {
        $subject  = "New abuse report on " . SITE_CONFIG_SITE_NAME;
        $plainMsg = "There is a new abuse report on " . SITE_CONFIG_SITE_NAME . " for the following url:\n\n";
        $plainMsg .= $_REQUEST['problemUrl'] . " " . ((int) $_REQUEST['url'] ? $_REQUEST['url'] : "") . "\n\n";
        $plainMsg .= "Please login via " . WEB_ROOT . "/admin/ to investigate further.";
        send_html_mail(SITE_CONFIG_REPORT_ABUSE_EMAIL, $subject, str_replace("\n", "<br/>", $plainMsg), SITE_CONFIG_REPORT_ABUSE_EMAIL, $plainMsg);
        redirect(WEB_ROOT.'/report_url.'.SITE_CONFIG_PAGE_EXTENSION.'?s=1');
    }
}

if (isset($_REQUEST['s']))
{
    setSuccess(t("report_url_sent", "The url has been reported."));
}

require_once('_header.php');
?>

<div class="span12">

    <?php
    if (isSuccess())
    {
        echo outputSuccess();
    }
    elseif (isErrors())
    {
        echo outputErrors();
    }
    ?>

    <!-- report url form -->
    <div class="well">
        <div>
            <p>
                <?php echo t("report_abuse_intro"); ?>
            </p>
            <form method="post" action="<?php echo WEB_ROOT; ?>/report_url.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>" class="form" AUTOCOMPLETE="off">
                <div>
                    <label for="problemUrl">
                        <?php echo t("problem_url"); ?>:
                    </label>
                    <input type="text" tabindex="1" value="<?php echo isset($_REQUEST['problemUrl']) ? safeOutputToScreen($_REQUEST['problemUrl']) : ''; ?>" id="problemUrlMain" name="problemUrl">
                </div>
                    
                <div class="buttonWrapper">
                    <input name="url" id="url" type="hidden" value="<?php echo (int) $_REQUEST['url']; ?>"/>
                    <input name="submitme" type="hidden" value="1"/>
                    <button type="submit" name="submit" class="btn btn-primary" tabindex="99"><?php echo t("submit_report", "submit report"); ?></button>
                </div>
                <div class="clear"></div>
            </form>
            <div class="clear"></div>
        </div>
    </div>
</div>

<?php
require_once('_footer.php');
?>