<?php
/* setup includes */
require_once('includes/master.inc.php');

/* setup page */
define("PAGE_NAME", t("register_page_name", "Register"));
define("PAGE_DESCRIPTION", t("register_meta_description", "Register for an account"));
define("PAGE_KEYWORDS", t("register_meta_keywords", "register, account, short, url, user"));
define("SITE_SELECTED_PAGE", "register");

if($_REQUEST['error'])
{
	setError(urldecode($_REQUEST['error']));
}

/* register user */
if ((int) $_REQUEST['submitme'])
{
    // validation
    $title               = trim($_REQUEST['title']);
    $firstname           = trim($_REQUEST['firstname']);
    $lastname            = trim($_REQUEST['lastname']);
    $emailAddress        = trim(strtolower($_REQUEST['emailAddress']));
    $emailAddressConfirm = trim(strtolower($_REQUEST['emailAddressConfirm']));
    $username            = trim(strtolower($_REQUEST['username']));

    if (!strlen($title))
    {
        setError(t("please_enter_your_title", "Please enter your title"));
    }
    elseif (!strlen($firstname))
    {
        setError(t("please_enter_your_firstname", "Please enter your firstname"));
    }
    elseif (!strlen($lastname))
    {
        setError(t("please_enter_your_lastname", "Please enter your lastname"));
    }
    elseif (!strlen($emailAddress))
    {
        setError(t("please_enter_your_email_address", "Please enter your email address"));
    }
    elseif ($emailAddress != $emailAddressConfirm)
    {
        setError(t("your_email_address_confirmation_does_not_match", "Your email address confirmation does not match"));
    }
    elseif (!valid_email($emailAddress))
    {
        setError(t("your_email_address_is_invalid", "Your email address is invalid"));
    }
    elseif (!strlen($username))
    {
        setError(t("please_enter_your_preferred_username", "Please enter your preferred username"));
    }
    elseif ((strlen($username) < 6) || (strlen($username) > 20))
    {
        setError(t("username_must_be_between_6_and_20_characters", "Your username must be between 6 and 20 characters"));
    }
    else
    {
        $checkEmail = UserPeer::loadUserByEmailAddress($emailAddress);
        if ($checkEmail)
        {
            // username exists
            setError(t("email_address_already_exists", "Email address already exists"));
        }
        else
        {
            $checkUser = UserPeer::loadUserByUsername($username);
            if ($checkUser)
            {
                // username exists
                setError(t("username_already_exists", "Username already exists"));
            }
        }
    }
    
    // check captcha
    if((!isErrors()) && (SITE_CONFIG_REGISTER_FORM_SHOW_CAPTCHA == 'yes'))
    {
        if (!isset($_REQUEST['g-recaptcha-response']))
        {
            setError(t("invalid_captcha", "Captcha confirmation text is invalid."));
        }
        else
        {
            $resp = verifyCaptcha($_POST["g-recaptcha-response"]);
            if ($resp == false)
            {
                setError(t("invalid_captcha", "Captcha confirmation text is invalid."));
            }
        }
    }

    // create the account
    if (!isErrors())
    {
        $newPassword = createPassword();
        $newUser     = UserPeer::create($username, $newPassword, $emailAddress, $title, $firstname, $lastname);
        if ($newUser)
        {
            $subject  = "Account details for " . SITE_CONFIG_SITE_NAME;
            $defaultContent = "Dear [[[FIRSTNAME]]],<br/><br/>";
            $defaultContent .= "Your account on [[[SITE_CONFIG_SITE_NAME]]] has been created. Use the details below to login to your new account:<br/><br/>";
            $defaultContent .= "<strong>Url:</strong> <a href='[[[WEB_ROOT]]]'>[[[WEB_ROOT]]]</a><br/>";
            $defaultContent .= "<strong>Username:</strong> [[[NEW_USERNAME]]]<br/>";
            $defaultContent .= "<strong>Password:</strong> [[[NEW_PASSWORD]]]<br/><br/>";
            $defaultContent .= "Feel free to contact us if you need any support with your account.<br/><br/>";
            $defaultContent .= "Regards,<br/>";
            $defaultContent .= "[[[SITE_CONFIG_SITE_NAME]]] Admin";
            
            $replacements = array();
            $replacements['NEW_PASSWORD'] = $newPassword;
            $replacements['NEW_USERNAME'] = $username;
            $replacements['WEB_ROOT'] = WEB_ROOT;
            $replacements['SITE_CONFIG_SITE_NAME'] = SITE_CONFIG_SITE_NAME;
            $replacements['FIRSTNAME'] = $firstname;
            
            $htmlMsg = t('email_content_new_registration', $defaultContent, $replacements);

            send_html_mail($emailAddress, $subject, $htmlMsg, SITE_CONFIG_DEFAULT_EMAIL_ADDRESS_FROM, strip_tags(str_replace("<br/>", "\n", $htmlMsg)));
            redirect(WEB_ROOT . "/register_complete." . SITE_CONFIG_PAGE_EXTENSION);
        }
        else
        {
            setError(t("problem_creating_your_account_try_again_later", "There was a problem creating your account, please try again later"));
        }
    }
}

require_once('_header.php');
?>

<!-- register form -->
<div class="span9 page_sidebar registerForm">
    <?php
    if (isErrors())
    {
        echo outputErrors();
    }
    ?>
    <div class="well">
        <p>
            <?php echo t('register_intro_text', 'Please enter your information below to register for an account. Your new account password will be sent to your email address.'); ?>
        </p>

        <form method="post" action="<?php echo WEB_ROOT; ?>/register.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>" class="form">
            <div class="third">
                <label for="title">
                    <?php echo t("title", "title"); ?>:
                </label>
                <select autofocus="autofocus" tabindex="1" id="title" name="title">
					<option value="Mr"><?php echo t('title_mr', 'Mr'); ?></option>
                    <option value="Mrs"><?php echo t('title_mrs', 'Mrs'); ?></option>
                    <option value="Miss"><?php echo t('title_miss', 'Miss'); ?></option>
                    <option value="Dr"><?php echo t('title_dr', 'Dr'); ?></option>
                    <option value="Pro"><?php echo t('title_pro', 'Pro'); ?></option>
                </select>
            </div>

            <div class="third">
                <label for="firstname">
                    <?php echo t("firstname", "firstname"); ?>:
                </label>
                <input type="text" tabindex="1" value="<?php echo isset($firstname) ? safeOutputToScreen($firstname) : ''; ?>" id="firstname" name="firstname">
            </div>

            <div class="thirdLast">
                <label for="lastname">
                    <?php echo t("lastname", "lastname"); ?>:
                </label>
                <input type="text" tabindex="1" value="<?php echo isset($lastname) ? safeOutputToScreen($lastname) : ''; ?>" id="lastname" name="lastname">
            </div>
            <div class="clear"></div>

            <div>
                <label for="emailAddress">
                    <?php echo t("email_address", "email address"); ?>:
                </label>
                <input type="text" tabindex="1" value="<?php echo isset($emailAddress) ? safeOutputToScreen($emailAddress) : ''; ?>" id="emailAddress" name="emailAddress">
            </div>

            <div>
                <label for="emailAddressConfirm">
                    <?php echo t("email_address_confirm", "Email Confirm"); ?>:
                </label>
                <input type="text" tabindex="2" value="<?php echo isset($emailAddressConfirm) ? safeOutputToScreen($emailAddressConfirm) : ''; ?>" id="emailAddressConfirm" name="emailAddressConfirm">
            </div>

            <div class="thirdLast">
                <label for="username">
                    <?php echo t("username", "username"); ?>:
                </label>
                <input type="text" tabindex="3" value="<?php echo isset($username) ? safeOutputToScreen($username) : ''; ?>" id="username" name="username">
            </div>
            <div class="clear"></div>
            
            <?php if(SITE_CONFIG_REGISTER_FORM_SHOW_CAPTCHA == 'yes'): ?>
            <div class="thirdLast">
                <label for="recaptcha_response_field">
                    <span class="field-name"><?php echo t("confirm_text", "Confirmation Text"); ?></span>
                </label>
                <div>
                    <?php echo outputCaptcha(); ?>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            <?php endif; ?>

            <div class="buttonWrapper">
                <button type="submit" name="submit" class="btn btn-primary" tabindex="99"><?php echo t("register", "register"); ?></button>
            </div>

            <input type="hidden" value="1" name="submitme"/>
        </form>

        <div class="disclaimer">
            <?php echo t('by_clicking_register_you_agree_to_our_terms', 'By clicking \'register\', you agree to our <a href="terms.[[[SITE_CONFIG_PAGE_EXTENSION]]]" target="_blank">terms</a>.', array('SITE_CONFIG_PAGE_EXTENSION'=>SITE_CONFIG_PAGE_EXTENSION)); ?>
        </div>
        <div class="clear"></div>
    </div>
</div>

<?php include_once("_bannerRightContent.inc.php"); ?>
<div class="clear"><!-- --></div>


<?php
require_once('_footer.php');
?>