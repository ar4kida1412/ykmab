<?php
/* setup includes */
require_once('includes/master.inc.php');

/* require login */
$Auth->requireUser('login.php');

/* load user */
$user = UserPeer::loadUserById($Auth->id);
if (!$user)
{
    redirect(WEB_ROOT);
}

if (SITE_CONFIG_ENABLE_API == 'yes')
{
    $apiKey = trim($user->apikey);
    if ((strlen($apiKey) == 0) || (isset($_REQUEST['rapi'])))
    {
        // create api key
        $apiKey = UserPeer::createApiKey();

        // save in db
        $db->query('UPDATE users SET apikey = :apikey WHERE id = :id', array('apikey' => $apiKey, 'id'     => $Auth->id));
    }
}

/* setup page */
define("PAGE_NAME", t("account_edit_page_name", "Account Details"));
define("PAGE_DESCRIPTION", t("account_edit_meta_description", "Account details"));
define("PAGE_KEYWORDS", t("account_edit_meta_keywords", "details, account, short, url, user"));
define("SITE_SELECTED_PAGE", "account_edit");

/* update user */
if ((int) $_REQUEST['submitme'])
{
    // validation
    $title        = trim($_REQUEST['title']);
    $firstname    = trim($_REQUEST['firstname']);
    $lastname     = trim($_REQUEST['lastname']);
    $emailAddress = trim(strtolower($_REQUEST['emailAddress']));
    $password     = trim($_REQUEST['password']);    
    $statistics   = (int)$_REQUEST['statistics'];

    if (!strlen($title))
    {
        setError(t("please_enter_your_title", "Please enter your title"));
    }
    elseif (!strlen($firstname))
    {
        setError(t("please_enter_your_firstname", "Please enter your firstname"));
    }
    elseif (!strlen($lastname))
    {
        setError(t("please_enter_your_lastname", "Please enter your lastname"));
    }
    elseif (!strlen($emailAddress))
    {
        setError(t("please_enter_your_email_address", "Please enter your email address"));
    }
    elseif (!valid_email($emailAddress))
    {
        setError(t("your_email_address_is_invalid", "Your email address is invalid"));
    }
    elseif (_CONFIG_DEMO_MODE == true)
    {
        setError(t("no_changes_in_demo_mode"));
    }
    else
    {
        $checkEmail = UserPeer::loadUserByEmailAddress($emailAddress);
        if (($checkEmail) && ($checkEmail->id != $Auth->id))
        {
            // username exists
            setError(t("email_address_already_exists", "Email address already exists on another account"));
        }
        else
        {
            // check password if one set
            if (strlen($password))
            {
                if ((strlen($password) < 6) || (strlen($password) > 20))
                {
                    setError(t("password_length_incorrect", "Password should be between 6 - 20 characters in length"));
                }
                elseif (containsInvalidCharacters(strtolower($password, 'abcdefghijklmnopqrstuvwxyz1234567890@~#!-_£$&*()^%}{()')))
                {
                    setError(t("password_contains_illegal_characters", "Password contains invalid characters, please choose another."));
                }
            }
        }
    }

    // update the account
    if (!isErrors())
    {
        $db = Database::getDatabase(true);
        $rs = $db->query('UPDATE users SET title = :title, firstname = :firstname, lastname = :lastname, email = :email, privateUrlStatistics = :privateUrlStatistics WHERE id = :id', array('title'     => $title, 'firstname' => $firstname, 'lastname'  => $lastname, 'email'     => $emailAddress, 'privateUrlStatistics' => $statistics, 'id'        => $Auth->id));
        if ($rs)
        {
            // do password
            if (strlen($password))
            {
                $rs = $db->query('UPDATE users SET password = :password WHERE id = :id', array('password' => MD5($password), 'id'       => $Auth->id));
            }
            setSuccess(t("account_updated_success_message", "Account details successfully updated"));
        }
        else
        {
            setError(t("problem_creating_your_account_try_again_later", "There was a problem creating your account, please try again later"));
        }
    }
}
else
{
    $title        = $user->title;
    $firstname    = $user->firstname;
    $lastname     = $user->lastname;
    $emailAddress = $user->email;
    $statistics   = $user->privateUrlStatistics;
    $userLevel    = $user->level;
    $paidExpiry   = $user->paidExpiryDate;
}

require_once('_header.php');
?>

<div class="span9 page_sidebar accountDetails">

    <?php
    if (isSuccess())
    {
        echo outputSuccess();
    }
    elseif (isErrors())
    {
        echo outputErrors();
    }
    ?>

    <div class="well">
        <h5><?php echo t("account_details", "Account Details"); ?></h5>
        <hr/>
        <p>
            <?php echo t('keep_your_account_details_up_to_date_below', 'Keep your account details up to date below.'); ?>
        </p>
        <form method="post" action="<?php echo WEB_ROOT; ?>/account_edit.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>" class="form">
            <div>
            <?php if($userLevel == 'paid user'): ?>
            <p><?php echo t('premium_account_expiry', 'Premium Account Expiry'); ?>: <?php echo dater($paidExpiry); ?></p>
            <?php endif; ?>
            </div>
            <div class="third">
                <label for="title">
                    <?php echo t("title", "Title"); ?>:
                </label>
                <select autofocus="autofocus" tabindex="1" id="title" name="title">
                    <option value="Mr" <?php echo ($title == 'Mr') ? 'SELECTED' : ''; ?>><?php echo t('title_mr', 'Mr'); ?></option>
                    <option value="Mrs" <?php echo ($title == 'Mrs') ? 'SELECTED' : ''; ?>><?php echo t('title_mrs', 'Mrs'); ?></option>
                    <option value="Miss" <?php echo ($title == 'Miss') ? 'SELECTED' : ''; ?>><?php echo t('title_miss', 'Miss'); ?></option>
                    <option value="Dr" <?php echo ($title == 'Dr') ? 'SELECTED' : ''; ?>><?php echo t('title_dr', 'Dr'); ?></option>
                    <option value="Pro" <?php echo ($title == 'Pro') ? 'SELECTED' : ''; ?>><?php echo t('title_pro', 'Pro'); ?></option>
                </select>
            </div>

            <div class="third">
                <label for="firstname">
                    <?php echo t("firstname", "Firstname"); ?>:
                </label>
                <input type="text" tabindex="1" value="<?php echo isset($firstname) ? safeOutputToScreen($firstname) : ''; ?>" id="firstname" name="firstname">
            </div>

            <div class="thirdLast">
                <label for="lastname">
                    <?php echo t("lastname", "Lastname"); ?>:
                </label>
                <input type="text" tabindex="1" value="<?php echo isset($lastname) ? safeOutputToScreen($lastname) : ''; ?>" id="lastname" name="lastname">
            </div>
			<div class="clear"></div>
            <div>
                <label for="emailAddress">
                    <?php echo t("email_address", "Email Address"); ?>:
                </label>
                <input type="text" tabindex="1" value="<?php echo isset($emailAddress) ? safeOutputToScreen($emailAddress) : ''; ?>" id="emailAddress" name="emailAddress">
            </div>

            <div class="fiftyPercentLast">
                <label for="password">
                    <?php echo t("change_password", "Change Password"); ?>:
                </label>
                <input type="password" tabindex="3" value="" id="password" name="password" autocomplete="off">
            </div>
            <div class="clear"></div>
            
            <div class="third">
                <label for="private_statistics">
                    <?php echo t("statistics_private_public", "Private/Public URL Statistics"); ?>:
                </label>
                <select autofocus="autofocus" tabindex="4" id="statistics" name="statistics">
                    <option value="1" <?php echo ($statistics == '1') ? 'selected="selected"' : ''; ?>><?php echo t('private_statistics', 'Private URL Statistics'); ?></option>
                    <option value="0" <?php echo ($statistics == '0') ? 'selected="selected"' : ''; ?>><?php echo t('public_statistics', 'Public URL Statistics'); ?></option>
                </select>
            </div>
            <div class="clear"></div>

            <?php if (SITE_CONFIG_ENABLE_API == 'yes'): ?>
                <div>
                    <label for="apiKey">
                        <?php echo t("api_key", "API Key"); ?>:
                    </label>
                    <div style="padding-top: 4px;"><code><?php echo $apiKey; ?></code>&nbsp;&nbsp;&nbsp;<a href="account_edit.<?php echo SITE_CONFIG_PAGE_EXTENSION; ?>?rapi=1" onClick="return confirm('<?php echo t('are_you_sure_you_want_to_create_a_new_api_key', 'Are you sure you want to create a new API key, any existing API connections will no longer function?'); ?>');">(<?php echo t('regenerate', 'regenerate'); ?>)</a></div>
                </div>
                <div class="clear"></div>
            <?php endif; ?>
            <div class="clear" style="padding-bottom: 18px;"></div>

            <div class="buttonWrapper">
                <button type="submit" name="submit" class="btn btn-primary" tabindex="99"><?php echo t("update_account", "update account"); ?></button>
            </div>
            <div class="clear"></div>

            <input type="hidden" value="1" name="submitme"/>
        </form>
    </div>
</div>
<?php include_once("_bannerRightContent.inc.php"); ?>

<?php
require_once('_footer.php');
?>