<?php

/**
 * main shortURl class
 */
define("SHORT_URL_PREFIX", "");  /* prefix on all the shorturl parts */

class shortUrl
{
    public $shortUrlUID  = null;
    public $shortUrlPart = "";
    public $fullUrl      = "";

    function __construct($fullUrl = null)
    {
        if ($fullUrl)
        {
            $this->fullUrl = $this->standardiseUrl($fullUrl);
        }
    }

    function compileShortUrl()
    {
        return shortUrl::getShortUrlDomain($this->urlDomainId) . "/" . SHORT_URL_PREFIX . $this->shortUrlPart;
    }

    function expire()
    {
        $db = Database::getDatabase(true);
        $this->visits++;
        $db->query('UPDATE shorturl SET status = :status WHERE id = :id', array('status' => 'expired', 'id'     => $this->shortUrlUID));
    }
    
    function disable()
    {
        $db = Database::getDatabase(true);
        $db->query('UPDATE shorturl SET status = :status WHERE id = :id', array('status' => 'disable', 'id'     => $this->shortUrlUID));
    }
    
    function activate()
    {
        $db = Database::getDatabase(true);
        $db->query('UPDATE shorturl SET status = :status WHERE id = :id', array('status' => 'active', 'id'     => $this->shortUrlUID));
    }

	static function standardiseUrl($url)
    {
        if (!strstr($url, "://"))
        {
            $url = "http://" . $url;
        }		
		// remove any js & tags
		$url = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', "", $url); 
		$url = strip_tags($url);
		
        return $url;
    }

    function getFormattedLongUrl($length = 36)
    {
        $x = substr($this->fullUrl, 7, $length);
        if (strlen($this->fullUrl) > $length + 7)
            $x .= ' ...';
        return $x;
    }

    function createShortUrl($shortUrlOverride = null, $batchTime = null, $isAPI = false)
    {
        if (!$this->fullUrl)
        {
            return false;
        }
        
        if($batchTime == null)
        {
            $batchTime = time();
        }
        
        $db = Database::getDatabase(true);

        /* check for spamming */
        if (SITE_CONFIG_MAX_URLS_PER_DAY > 0)
        {
            $urlTodayTotal = $db->getValue('SELECT COUNT(id) AS total FROM shorturl WHERE createdIP = \'' . getUsersIPAddress() . '\' AND MID(dateCreated, 1, 10) = \'' . date("Y-m-d") . '\'');
            if ($urlTodayTotal > SITE_CONFIG_MAX_URLS_PER_DAY)
            {
                setError(t("you_have_reached_the_maximum_urls_permitted_for_today", "You have reached the maximum urls permitted for today, please try again tomorrow."));
                return false;
            }
        }

        if (((int) SITE_CONFIG_DELAY_BETWEEN_SUBMISSIONS > 0) && ($isAPI == false))
        {
            $urlTodayTotal = $db->getValue('SELECT COUNT(id) AS total FROM shorturl WHERE createdIP = \'' . getUsersIPAddress() . '\' AND dateCreated > \'' . date("Y-m-d H:i:s", strtotime("- " . (int) SITE_CONFIG_DELAY_BETWEEN_SUBMISSIONS . " seconds")) . '\' AND dateCreated != \'' . date("Y-m-d H:i:s", $batchTime) . '\'');
            if ((int) $urlTodayTotal > 0)
            {
                setError(t("there_is_a_restriction_of_x_seconds_between_submissions", "There is a restriction of [[[SITE_CONFIG_DELAY_BETWEEN_SUBMISSIONS]]] seconds between submissions.", array('SITE_CONFIG_DELAY_BETWEEN_SUBMISSIONS'=>(int)SITE_CONFIG_DELAY_BETWEEN_SUBMISSIONS)));
                return false;
            }
        }

        /* check for banned words */
        $bannedWords = $db->getRows('SELECT bannedTerm FROM banned_words');
        if (COUNT($bannedWords))
        {
            foreach ($bannedWords AS $bannedWord)
            {
                // check url
                if (strpos($this->fullUrl, $bannedWord['bannedTerm']) !== false)
                {
                    setError(t("the_url_submitted_contains_a_banned_term_domain_name", "The url submitted contains a banned term/domain name."));
                    return false;
                }

                // check short url part
                if ($shortUrlOverride != null)
                {
                    if (strpos($shortUrlOverride, $bannedWord['bannedTerm']) !== false)
                    {
                        setError(t("the_custom_short_url_contains_a_banned_term", "The custom short url contains a banned term."));
                        return false;
                    }
                }
            }
        }

        /* create the intial record */
        $dbInsert = new DBObject("shorturl", array("shortUrl", "originalUrl", "dateCreated", "createdIP", "visits", "isPrivate", "password", "expiryDate", "totalUses", "userId", "urlDomainId", "shortUrlFolder"));
        $dbInsert->originalUrl = $this->fullUrl;
        $dbInsert->dateCreated = sqlDateTime();
        $dbInsert->createdIP = getUsersIPAddress();
        $dbInsert->visits = 0;
        $dbInsert->isPrivate = (int) $this->isPrivate;
        $dbInsert->password = $this->password;
        $dbInsert->expiryDate = strlen($this->expiryDate)?$this->expiryDate:null;
        $dbInsert->totalUses = (int) $this->totalUses;
        $dbInsert->status = $this->status ? $this->status : "active";
        $dbInsert->userId = $this->userId;
        $dbInsert->urlDomainId = $this->urlDomainId;
        $dbInsert->shortUrlFolder = (int)$this->shortUrlFolder?$this->shortUrlFolder:null;
        if (!$this->shortUrlUID = $dbInsert->insert())
        {
            return false;
        }

        /* create the shorturl */
        if (!$shortUrlOverride)
        {
            $tracker     = 1;
            $shortUrlObj = $this->createShortUrlPart($tracker . $this->shortUrlUID);
            while ($shortUrlObj)
            {
                $shortUrlPart = $this->createShortUrlPart($tracker . $this->shortUrlUID);
                $shortUrlObj  = shortUrl::loadByUrl($shortUrlPart);
                $tracker++;
            }
            $this->shortUrlPart = $shortUrlPart;
        }
        else
        {
            $this->shortUrlPart = $shortUrlOverride;
        }
		
        // update the short url part
        $db->query('UPDATE shorturl SET shortUrl = :shortUrl WHERE id = :id', array('shortUrl' => $this->shortUrlPart, 'id'     => $this->shortUrlUID));
		
        return shortUrl::loadById($this->shortUrlUID);
    }

    /* method to increment visitors */

    public function updateVisitors()
    {
        $db = Database::getDatabase(true);
        $this->visits++;
        $db->query('UPDATE shorturl SET visits = :visits WHERE id = :id', array('visits' => $this->visits, 'id'     => $this->shortUrlUID));
    }

    /* method to update last accessed */

    public function updateLastAccessed()
    {
        $db = Database::getDatabase(true);
        $db->query('UPDATE shorturl SET lastAccessed = NOW() WHERE id = :id', array('id' => $this->shortUrlUID));
    }

    /* loader method */

    static function loadByUrl($shortUrl)
    {
        $db  = Database::getDatabase(true);
        $row = $db->getRow('SELECT * FROM shorturl WHERE shortUrl = ' . $db->quote($shortUrl));
        if (!is_array($row))
        {
            return false;
        }

        $shortUrlObj = new shortUrl();
        $shortUrlObj->id = $row['id'];
        $shortUrlObj->shortUrlUID = $row['id'];
        $shortUrlObj->shortUrlPart = $shortUrl;
        $shortUrlObj->fullUrl = $row['originalUrl'];
        $shortUrlObj->dateCreated = $row['dateCreated'];
        $shortUrlObj->createdIP = $row['createdIP'];
        $shortUrlObj->visits = $row['visits'];
        $shortUrlObj->isPrivate = $row['isPrivate'];
        $shortUrlObj->password = $row['password'];
        $shortUrlObj->expiryDate = $row['expiryDate'];
        $shortUrlObj->totalUses = $row['totalUses'];
        $shortUrlObj->status = $row['status'];
        $shortUrlObj->userId = $row['userId'];
        $shortUrlObj->lastAccessed = $row['lastAccessed'];
        $shortUrlObj->urlDomainId = $row['urlDomainId'];
        $shortUrlObj->shortUrlFolder = $row['shortUrlFolder'];
        
        return $shortUrlObj;
    }

    static function loadAllByAccount($accountId, $activeOnly=false)
    {
        $db = Database::getDatabase(true);
        $sQL = 'SELECT * FROM shorturl WHERE userId = ' . $db->quote($accountId) . ' ';
        if($activeOnly == true)
        {
            $sQL .= 'AND status=\'active\' ';
        }
        $sQL .= ' ORDER BY shortUrl';
        $rs = $db->getRows($sQL);
        if (!is_array($rs))
        {
            return false;
        }

        return $rs;
    }

    static function loadAllRecentByAccount($accountId, $activeOnly=false)
    {
        $db = Database::getDatabase(true);
        $sQL = 'SELECT * FROM shorturl WHERE userId = ' . $db->quote($accountId) . ' ';
        if($activeOnly == true)
        {
            $sQL .= 'AND status=\'active\' ';
        }
        $sQL .= ' ORDER BY dateCreated DESC LIMIT 10';
        $rs = $db->getRows($sQL);
        if (!is_array($rs))
        {
            return false;
        }

        return $rs;
    }
    
    static function loadAllRecentActive()
    {
        $db = Database::getDatabase(true);
        $sQL = 'SELECT * FROM shorturl WHERE AND status=\'active\' ';
        $sQL .= ' ORDER BY dateCreated DESC LIMIT 10';
        $rs = $db->getRows($sQL);
        if (!is_array($rs))
        {
            return false;
        }

        return $rs;
    }

    static function loadAllRecentByIp($ip)
    {
        $db = Database::getDatabase(true);
        $rs = $db->getRows('SELECT * FROM shorturl WHERE createdIP = ' . $db->quote($ip) . ' ORDER BY dateCreated DESC LIMIT 10');
        if (!is_array($rs))
        {
            return false;
        }

        return $rs;
    }

    static function loadByOriginalUrl($originalUrl)
    {
        $db  = Database::getDatabase(true);
        $row = $db->getRow('SELECT * FROM shorturl WHERE originalUrl = ' . $db->quote($originalUrl));
        if (!is_array($row))
        {
            return false;
        }

        $shortUrlObj = new shortUrl();
        $shortUrlObj->id = $row['id'];
        $shortUrlObj->shortUrlUID = $row['id'];
        $shortUrlObj->shortUrlPart = $row['shortUrl'];
        $shortUrlObj->fullUrl = $row['originalUrl'];
        $shortUrlObj->dateCreated = $row['dateCreated'];
        $shortUrlObj->createdIP = $row['createdIP'];
        $shortUrlObj->visits = $row['visits'];
        $shortUrlObj->isPrivate = $row['isPrivate'];
        $shortUrlObj->password = $row['password'];
        $shortUrlObj->expiryDate = $row['expiryDate'];
        $shortUrlObj->totalUses = $row['totalUses'];
        $shortUrlObj->status = $row['status'];
        $shortUrlObj->userId = $row['userId'];
        $shortUrlObj->urlDomainId = $row['urlDomainId'];
        $shortUrlObj->shortUrlFolder = $row['shortUrlFolder'];

        return $shortUrlObj;
    }

    static function loadById($recordId)
    {
        $db  = Database::getDatabase(true);
        $row = $db->getRow('SELECT * FROM shorturl WHERE id = ' . $db->quote($recordId));
        if (!is_array($row))
        {
            return false;
        }

        $shortUrlObj = new shortUrl();
        $shortUrlObj->id = $row['id'];
        $shortUrlObj->shortUrlUID = $row['id'];
        $shortUrlObj->shortUrlPart = $row['shortUrl'];
        $shortUrlObj->fullUrl = $row['originalUrl'];
        $shortUrlObj->dateCreated = $row['dateCreated'];
        $shortUrlObj->createdIP = $row['createdIP'];
        $shortUrlObj->visits = $row['visits'];
        $shortUrlObj->isPrivate = $row['isPrivate'];
        $shortUrlObj->password = $row['password'];
        $shortUrlObj->expiryDate = $row['expiryDate'];
        $shortUrlObj->totalUses = $row['totalUses'];
        $shortUrlObj->status = $row['status'];
        $shortUrlObj->userId = $row['userId'];
        $shortUrlObj->urlDomainId = $row['urlDomainId'];
        $shortUrlObj->shortUrlFolder = $row['shortUrlFolder'];

        return $shortUrlObj;
    }

    /* strip unwanted characters from custom short url */

    static function prepareShortUrlPart($str)
    {
        $str = trim($str);
        $str = str_replace(" ", "_", $str);
 
        return preg_replace("/[^a-zA-Z0-9_-]/", "", $str);
    }

    /**
     * Create short url
     *
     * @param integer $in
     * @return string
     */
    static function createShortUrlPart($in)
    {
        // note: no need to check whether it already exists as it's handled by the code which calls this
        switch (SITE_CONFIG_GENERATE_SHORT_URL_TYPE)
        {
            case 'Medium Hash':
                return substr(MD5($in . microtime()), 0, 16);
                break;
            case 'Long Hash':
                return MD5($in . microtime());
                break;
        }

        // Shortest
        $codeset  = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $cbLength = strlen($codeset);
        while ((int) $in > $cbLength - 1)
        {
            $out = $codeset[fmod($in, $cbLength)] . $out;
            $in  = floor($in / $cbLength);
        }

        return $codeset[$in] . $out;
    }

    static function formatLongUrlForScreen($url)
    {
        if (strlen($url) > 50)
        {
            $endPart   = substr($url, strlen($url) - 5, 5);
            $startPart = substr($url, 0, 40);
            $url       = $startPart . '&nbsp;...' . $endPart;
        }

        return $url;
    }

    static function getFavIconUrl($url)
    {
        $expUrl  = explode("/", $url);
        $baseUrl = "http://" . $expUrl[2];

        return $baseUrl . "/favicon.ico";
    }
    
    static function getShortUrlDomain($domainId)
    {
        // get base urls
        $shortUrlDomains = getShortUrlDomains();
        
        if(!isset($shortUrlDomains[$domainId]))
        {
            return _CONFIG_SITE_PROTOCOL.'://'._CONFIG_SITE_FULL_URL;
        }
        
        return _CONFIG_SITE_PROTOCOL.'://'.$shortUrlDomains[$domainId]['domain'];
    }
    
    /**
     * Whether stats data is private and can only be viewed by the account owner
     * 
     * @return boolean
     */
    public function canViewStats()
    {
        // check for admin users, they should be allowed access to all
        $Auth = Auth::getAuth();
        if ($Auth->level_id >= 10)
        {
            return true;
        }

        // if url doesn't belong to an account, assume public
        if ((int) $this->userId == 0)
        {
            return true;
        }

        // if logged in user matches owner
        if ($Auth->id == $this->userId)
        {
            return true;
        }

        // user not logged in or other account, load url owner and see if flagged as private
        $owner = UserPeer::loadUserById($this->userId);
        if (!$owner)
        {
            return true;
        }

        // check if stats are public or private on account, 0 = public
        if ($owner->privateUrlStatistics == 0)
        {
            return true;
        }

        return false;
    }

}
