<?php

class UserPeer
{

    // Singleton object. Leave $me alone.
    private static $me;

    static function create($username, $password, $email, $title, $firstname, $lastname, $accType = 'user')
    {
        $dbInsert = new DBObject("users",
                        array("username", "password", "email",
                            "title", "firstname", "lastname", "datecreated",
                            "createdip", "status")
        );
        $dbInsert->username = $username;
        $dbInsert->password = MD5($password);
        $dbInsert->email = $email;
        $dbInsert->title = $title;
        $dbInsert->firstname = $firstname;
        $dbInsert->lastname = $lastname;
        $dbInsert->datecreated = sqlDateTime();
        $dbInsert->createdip = getUsersIPAddress();
        $dbInsert->status = 'active';
        if ($dbInsert->insert())
        {
            // create default folder
            $db = Database::getDatabase(true);
            $db->query('INSERT INTO shorturl_folder (user_id, folder_name, date_created) VALUES (:user_id, \'Default\', NOW())', array('user_id' => $dbInsert->id));
            
            return $dbInsert;
        }

        return false;
    }

    static function loadUserById($id)
    {
        $userObj = new User();
        $userObj->select($id, 'id');
        if (!$userObj->ok())
        {
            return false;
        }

        return $userObj;
    }

    static function loadUserByUsername($username)
    {
        $userObj = new User();
        $userObj->select($username, 'username');
        if (!$userObj->ok())
        {
            return false;
        }

        return $userObj;
    }

    static function loadUserByEmailAddress($email)
    {
        $userObj = new User();
        $userObj->select($email, 'email');
        if (!$userObj->ok())
        {
            return false;
        }

        return $userObj;
    }

    static function loadUserByAPIKey($apiKey)
    {
        $userObj = new User();
        $userObj->select($apiKey, 'apikey');
        if (!$userObj->ok())
        {
            return false;
        }

        return $userObj;
    }

    static function createApiKey()
    {
        $foundUser = true;

        // create unique key
        while ($foundUser == true)
        {
            // generate key
            $newKey = MD5(microtime() . rand(1000, 9999));

            // make sure it doesn't already exist on another account
            $foundUser = self::loadUserByAPIKey($newKey);
        }

        return $newKey;
    }

    static function loadUserByPasswordResetHash($hash)
    {
        $userObj = new User();
        $userObj->select($hash, 'passwordResetHash');
        if (!$userObj->ok())
        {
            return false;
        }

        return $userObj;
    }

    static function createPasswordResetHash($userId)
    {
        $user = true;

        // make sure it doesn't already exist on an account
        while ($user != false)
        {
            // create hash
            $hash = MD5(microtime() . $userId);

            // lookup by hash
            $user = self::loadUserByPasswordResetHash($hash);
        }

        // update user with hash
        $db = Database::getDatabase(true);
        $db->query('UPDATE users SET passwordResetHash = :passwordResetHash WHERE id = :id', array('passwordResetHash' => $hash, 'id'                => $userId));

        return $hash;
    }
	
	static function enableUpgradePage($levelId = null)
    {
        if ($levelId === null)
        {
            $Auth    = Auth::getAuth();
            $levelId = $Auth->level_id;
        }

        switch ($levelId)
        {
            // free user
            case 1:
                return SITE_CONFIG_FREE_USER_SHOW_UPGRADE_PAGE;
            // non user
            case 0:
                return SITE_CONFIG_NON_USER_SHOW_UPGRADE_PAGE;
            // paid & admin users
            default:
                return SITE_CONFIG_PAID_USER_SHOW_UPGRADE_PAGE;
        }
    }
	
	static function upgradeUser($userId, $days)
    {
        // load user
        $user = UserPeer::loadUserById($userId);

        // upgrade user
        $newExpiryDate = strtotime('+' . $days . ' days');

        // exntend user
        if ($user->level_id >= 2)
        {
            // add onto existing period
            $existingExpiryDate = strtotime($user->paidExpiryDate);

            // if less than today just revert to now
            if ($existingExpiryDate < time())
            {
                $existingExpiryDate = time();
            }

            $newExpiryDate = (int) $existingExpiryDate + (int) ($days * (60 * 60 * 24));
        }

        // update user account to premium
        $dbUpdate                 = new DBObject("users", array("level", "lastPayment", "paidExpiryDate"), 'id');
        $dbUpdate->level          = 'paid user';
        $dbUpdate->lastPayment    = date("Y-m-d H:i:s", time());
        $dbUpdate->paidExpiryDate = date("Y-m-d H:i:s", $newExpiryDate);
        $dbUpdate->id             = $userId;
        $effectedRows             = $dbUpdate->update();
        if ($effectedRows === false)
        {
            // failed to update user
            return false;
        }

        return true;
    }

    static function downgradeExpiredAccounts()
    {
        // connect db
        $db = Database::getDatabase(true);

        // downgrade paid accounts
        $sQL = 'UPDATE users SET level = \'free user\' WHERE level = \'paid user\' AND UNIX_TIMESTAMP(paidExpiryDate) < ' . time();
        $rs  = $db->query($sQL);
    }

}
