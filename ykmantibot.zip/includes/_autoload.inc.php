<?php

// autoloader, included within the /includes/master.inc.php file
spl_autoload_register(function($className)
{
    if(is_file(DOC_ROOT . '/includes/class.' . strtolower($className) . '.php')) 
    { 
        require_once(DOC_ROOT . '/includes/class.' . strtolower($className) . '.php'); 
    }
});

// composer
include_once(__DIR__.'/vendor/autoload.php');
