<?php

// Application flag
define('SPF', true);

// Determine our absolute document root
define('DOC_ROOT', realpath(dirname(__FILE__) . '/../'));

// set timezone if not set, change to whatever timezone you want
if (!ini_get('date.timezone'))
{
    date_default_timezone_set('GMT');
}

// autoloader
require DOC_ROOT . '/includes/_autoload.inc.php';

require DOC_ROOT . '/includes/antibot.php';

// Global include files
require DOC_ROOT . '/includes/functions.inc.php'; // __autoload() is contained in this file
require DOC_ROOT . '/includes/class.dbobject.php';
require DOC_ROOT . '/includes/class.objects.php';
require DOC_ROOT . '/includes/email_class/class.smtp.php';
require DOC_ROOT . '/includes/email_class/class.phpmailer.php';
require DOC_ROOT . '/includes/phpqrcode/phpqrcode.php';

// Fix magic quotes
if (get_magic_quotes_gpc())
{
    $_POST    = fix_slashes($_POST);
    $_GET     = fix_slashes($_GET);
    $_REQUEST = fix_slashes($_REQUEST);
    $_COOKIE  = fix_slashes($_COOKIE);
}

// Load our config settings
$Config = Config::getConfig();

/* load db config settings into constants */
$db   = Database::getDatabase();
$rows = $db->getRows("SELECT config_key, config_value FROM site_config ORDER BY config_group, config_key");
if (COUNT($rows))
{
    foreach ($rows AS $row)
    {
        $constantName = "SITE_CONFIG_" . strtoupper($row['config_key']);
        define($constantName, $row['config_value']);
    }
}

// setup error handler
log::initErrorHandler();

// store session info in the database?
if ($Config->useDBSessions === true)
{
    DBSession::register();
}

// Initialize our session
session_name($Config->sessionName);
session_start();

// pick up any requests to change the site language
if (isset($_REQUEST['_t']))
{
    // make sure the one passed is an active language
    $isValidLanguage = $db->getRow("SELECT languageName, flag FROM language WHERE isActive = 1 AND languageName = '" . $db->escape(trim($_REQUEST['_t'])) . "' LIMIT 1");
    if ($isValidLanguage)
    {
        $_SESSION['_t'] = trim($_REQUEST['_t']);
    }
    else
    {
        $_SESSION['_t'] = SITE_CONFIG_SITE_LANGUAGE;
    }
}
// if we don't have the session variable set or if it's been set to 'SITE_CONFIG_SITE_LANGUAGE'
// (sometimes happens if the database hasn't initially been set correctly), store the current
// language in the session
elseif ((!isset($_SESSION['_t'])) || ($_SESSION['_t'] == 'SITE_CONFIG_SITE_LANGUAGE'))
{
    $_SESSION['_t'] = SITE_CONFIG_SITE_LANGUAGE;
}

/* setup translations */
translate::setUpTranslationConstants();

// Initialize current user
$Auth = Auth::getAuth();

define("SITE_IMAGE_PATH", WEB_ROOT . "/themes/" . SITE_CONFIG_SITE_THEME . "/images");
define("SITE_CSS_PATH", WEB_ROOT . "/themes/" . SITE_CONFIG_SITE_THEME . "/styles");
define("SITE_JS_PATH", WEB_ROOT . "/themes/" . SITE_CONFIG_SITE_THEME . "/js");

// the root plugin directory
define('PLUGIN_DIRECTORY_NAME', 'plugins');
define('PLUGIN_DIRECTORY_ROOT', DOC_ROOT . '/' . PLUGIN_DIRECTORY_NAME . '/');
define('PLUGIN_WEB_ROOT', WEB_ROOT . '/' . PLUGIN_DIRECTORY_NAME);

// admin paths
define('ADMIN_FOLDER_NAME', 'admin');
define('ADMIN_WEB_ROOT', WEB_ROOT . '/' . ADMIN_FOLDER_NAME);

// cache paths
define("CACHE_DIRECTORY_PATH", dirname(__DIR__).'/core/cache/');
define("CACHE_DIRECTORY_URL", WEB_ROOT . '/core/cache/');

/* check for banned ip */
$bannedIP = bannedIP::getBannedType();
if (strtolower($bannedIP) == "whole site")
{
    header('HTTP/1.1 404 Not Found');
    die();
}

// setup demo mode
if (_CONFIG_DEMO_MODE == true)
{
    if (isset($_REQUEST['_p']))
    {
        $_SESSION['_plugins'] = false;
        if ((int) $_REQUEST['_p'] == 1)
        {
            $_SESSION['_plugins'] = true;
        }
        unset($_SESSION['pluginConfigs']);
    }

    if (!isset($_SESSION['_plugins']))
    {
        $_SESSION['_plugins'] = true;
        unset($_SESSION['pluginConfigs']);
    }
}

// load plugin configuration into the session
if (!isset($_SESSION['pluginConfigs']))
{
    $_SESSION['pluginConfigs'] = pluginHelper::loadPluginConfigurationFiles();
}

// append any plugin includes
pluginHelper::includeAppends('master.inc.php');
